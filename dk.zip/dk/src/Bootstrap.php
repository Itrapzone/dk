<?php
declare(strict_types=1);

namespace App;

use App\Core\Container;
use App\Models\DB;
use Dotenv\Dotenv;
use League\Plates\Engine;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;

class Bootstrap
{
    public function boot(): Container
    {
        $root = dirname(__DIR__);

        // .env yükle
        if (file_exists($root . '/.env')) {
            Dotenv::createImmutable($root)->safeLoad();
        }

        $container = new Container();

        // Logger
        $logger = new Logger('app');
        $logger->pushHandler(new StreamHandler($root . '/storage.log', Logger::DEBUG));
        $container->set('logger', $logger);

        // DB
        $container->set('db', function () {
            return DB::fromEnv();
        });

        // Views (Plates)
        $templates = new Engine($root . '/views');
        $templates->setFileExtension('phtml');

        // Settings'i oku (varsa)
        $settings = [];
        try {
            /** @var \PDO $pdo */
            $pdo = $container->get('db');
            $settings = (new \App\Models\Settings($pdo))->getAll();
        } catch (\Throwable $e) {
            // settings tablosu henüz yoksa sessiz geç
            $settings = [];
        }

        // Basit asset versiyonlayıcı (cache-bust)
        $asset = function (string $path) use ($root): string {
            // Tam URL ise dokunma
            if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) {
                return $path;
            }
            // Göreli yolu normalize et
            if (!str_starts_with($path, '/')) {
                $path = '/' . $path;
            }
            $publicPath = $root . '/public' . $path;
            if (is_file($publicPath)) {
                return $path . '?v=' . filemtime($publicPath);
            }
            return $path;
        };

        // Tüm view'lara ortak veri
        $templates->addData([
            'appUrl'   => $_ENV['APP_URL'] ?? '',
            'session'  => &$_SESSION,
            'settings' => $settings,
            'asset'    => $asset,
        ]);

        $container->set('view', $templates);

        return $container;
    }
}

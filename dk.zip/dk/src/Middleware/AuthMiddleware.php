<?php
declare(strict_types=1);

namespace App\Middleware;

use App\Core\Container;

class AuthMiddleware
{
    public function __construct(private Container $c) {}

    public function handle(): void
    {
        if (empty($_SESSION['user'])) {
            header('Location: /login'); exit;
        }
    }
}

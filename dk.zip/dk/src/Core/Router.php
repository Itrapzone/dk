<?php
declare(strict_types=1);

namespace App\Core;

use FastRoute\RouteCollector;
use function FastRoute\simpleDispatcher;

class Router
{
    private Container $c;

    private ?string $groupPrefix = null;
    private ?string $groupMiddleware = null;

    private array $routes = [];

    public function __construct(Container $c) { $this->c = $c; }

    private function add(string $method, string $path, $handler): void
    {
        $full = ($this->groupPrefix ?? '') . $path;
        $this->routes[] = [$method, $full, $handler, $this->groupMiddleware];
    }

    public function get(string $path, $handler): void { $this->add('GET', $path, $handler); }
    public function post(string $path, $handler): void { $this->add('POST', $path, $handler); }

    public function group(string $prefix, callable $callback, ?string $middleware = null): void
    {
        $prevPrefix = $this->groupPrefix;
        $prevMw     = $this->groupMiddleware;

        $this->groupPrefix = ($prevPrefix ? $prevPrefix : '') . $prefix;
        $this->groupMiddleware = $middleware ?? $prevMw;

        $callback($this);

        $this->groupPrefix = $prevPrefix;
        $this->groupMiddleware = $prevMw;
    }

    public function dispatch(): void
    {
        $dispatcher = simpleDispatcher(function (RouteCollector $r) {
            foreach ($this->routes as [$method, $path, $handler]) {
                $r->addRoute($method, $path, $handler);
            }
        });

        $httpMethod = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);

        $routeInfo = $dispatcher->dispatch($httpMethod, $uri);
        switch ($routeInfo[0]) {
            case \FastRoute\Dispatcher::NOT_FOUND:
                http_response_code(404); echo '404'; return;
            case \FastRoute\Dispatcher::METHOD_NOT_ALLOWED:
                http_response_code(405); echo '405'; return;
            case \FastRoute\Dispatcher::FOUND:
                $handler = $routeInfo[1];
                $vars    = $routeInfo[2];

                $matchedMw = null;
                for ($i=0; $i<count($this->routes); $i++) {
                    [$m,$p,$h,$mw] = $this->routes[$i];
                    if ($m === $httpMethod && $p === $uri && $h === $handler) {
                        $matchedMw = $mw; break;
                    }
                }
                if ($matchedMw) {
                    (new $matchedMw($this->c))->handle();
                }

                if (is_array($handler)) {
                    [$class, $method] = $handler;
                    (new $class($this->c))->{$method}($vars);
                } else {
                    call_user_func($handler, $vars);
                }
        }
    }
}

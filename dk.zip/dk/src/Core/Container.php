<?php
declare(strict_types=1);

namespace App\Core;

class Container
{
    private array $entries = [];

    public function set(string $id, $value): void
    {
        $this->entries[$id] = $value;
    }

    public function get(string $id)
    {
        $entry = $this->entries[$id] ?? null;
        return is_callable($entry) ? $entry() : $entry;
    }
}

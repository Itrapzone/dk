<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\AdminTranslation;
use League\Plates\Engine;
use PDO;

class AdminLangController
{
    private Engine $view;
    private AdminTranslation $t;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->t    = new AdminTranslation($c->get('db'));
    }

    /** Liste */
    public function index(): void
    {
        $page = max(1, (int)($_GET['page'] ?? 1));
        $per  = max(1, (int)($_GET['per']  ?? 20));
        $q    = trim($_GET['q'] ?? '');

        // aktif diller
        $langs = $this->c->get('db')->query("SELECT code,name FROM languages WHERE is_active=1 ORDER BY sort_order")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $currentLang = $_GET['lang'] ?? ($langs[0]['code'] ?? 'tr');

        $data = $this->t->paginateKeys($page,$per,$q);
        echo $this->view->render('admin/languages/admin_index', [
            'rows'=>$data['rows'],'total'=>$data['total'],
            'page'=>$page,'per'=>$per,'q'=>$q,
            'langs'=>$langs,'currentLang'=>$currentLang
        ]);
    }

    /** Düzenleme formu */
    public function edit(array $params): void
    {
        $key  = $params['key'];
        $lang = $_GET['lang'] ?? 'tr';

        $row = $this->t->getOne($key,$lang);

        echo $this->view->render('admin/languages/admin_edit', [
            'row'=>$row,'lang'=>$lang
        ]);
    }

    /** Kaydet */
    public function update(array $params): void
    {
        $key  = $params['key'];
        $lang = $_POST['lang'] ?? 'tr';
        $desc = trim($_POST['description'] ?? '');
        $val  = trim($_POST['value'] ?? '');

        $this->t->upsert($key,$lang,$desc,$val);
        $_SESSION['flash'] = 'Çeviri kaydedildi.';
        header('Location: /admin/admin-lang?lang='.urlencode($lang));
    }
}

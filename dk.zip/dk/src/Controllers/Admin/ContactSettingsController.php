<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class ContactSettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/contact', ['s' => $s]);
    }

    public function save(): void
    {
        $payload = [
            'company_name'    => trim($_POST['company_name'] ?? ''),
            'company_phone'   => trim($_POST['company_phone'] ?? ''),
            'company_fax'     => trim($_POST['company_fax'] ?? ''),
            'company_email'   => trim($_POST['company_email'] ?? ''),
            'company_address' => trim($_POST['company_address'] ?? ''),
        ];

        // basit e-posta doğrulama (opsiyonel)
        if ($payload['company_email'] !== '' && !filter_var($payload['company_email'], FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = 'Lütfen geçerli bir e-posta girin.';
            header('Location: /admin/settings/contact'); return;
        }

        $this->settings->save($payload);
        $_SESSION['flash'] = 'İletişim ayarları güncellendi.';
        header('Location: /admin/settings/contact');
    }
}

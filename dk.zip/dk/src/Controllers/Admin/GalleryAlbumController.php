<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\GalleryAlbum;
use App\Models\GalleryPhoto;
use League\Plates\Engine;

class GalleryAlbumController
{
    private Engine $view;
    private GalleryAlbum $album;
    private GalleryPhoto $photo;

    public function __construct(private Container $c)
    {
        $this->view  = $c->get('view');
        $db          = $c->get('db');
        $this->album = new GalleryAlbum($db);
        $this->photo = new GalleryPhoto($db);
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1)); $per=max(1,(int)($_GET['per']??10)); $q=trim($_GET['q']??'');
        $data=$this->album->paginate($page,$per,$q);
        echo $this->view->render('admin/gallery_albums/index',[
          'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/gallery_albums/form',['row'=>null]); }

    public function store(): void
    {
        $payload=$this->collectAlbum($_POST,$_FILES);
        $id=$this->album->create($payload);
        $_SESSION['flash']='Albüm eklendi.'; header("Location: /admin/photo-galleries/{$id}/photos");
    }

    public function edit(array $p): void
    {
        $row=$this->album->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/gallery_albums/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id']; $payload=$this->collectAlbum($_POST,$_FILES,true);
        $this->album->update($id,$payload);
        $_SESSION['flash']='Albüm güncellendi.'; header("Location: /admin/photo-galleries/{$id}/edit");
    }

    public function destroy(array $p): void
    {
        $this->album->delete((int)$p['id']); $_SESSION['flash']='Albüm silindi.'; header('Location: /admin/photo-galleries');
    }

    public function toggle(array $p): void { $this->album->toggle((int)$p['id']); header('Location: /admin/photo-galleries'); }

    public function photos(array $p): void
    {
        $id=(int)$p['id']; $row=$this->album->find($id); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        $photos=$this->photo->allByAlbum($id);
        echo $this->view->render('admin/gallery_albums/photos', compact('row','photos'));
    }

    public function uploadPhotos(array $p): void
    {
        $albumId=(int)$p['id'];
        $root=dirname(__DIR__,3); $dir=$root.'/public/uploads/gallery/'.$albumId;
        if(!is_dir($dir)) mkdir($dir,0775,true);

        if (!empty($_FILES['images']['name']) && is_array($_FILES['images']['name'])) {
            $count=count($_FILES['images']['name']);
            for($i=0;$i<$count;$i++){
                if(($_FILES['images']['error'][$i]??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) continue;
                $ext=strtolower(pathinfo($_FILES['images']['name'][$i],PATHINFO_EXTENSION));
                if(!in_array($ext,['png','jpg','jpeg','gif','webp'],true)) continue;
                $target=$dir.'/img_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)).'.'.$ext;
                if(move_uploaded_file($_FILES['images']['tmp_name'][$i],$target)){
                    $url='/uploads/gallery/'.$albumId.'/'.basename($target);
                    $this->photo->add($albumId,$url);
                }
            }
        }
        $_SESSION['flash']='Fotoğraflar yüklendi.'; header("Location: /admin/photo-galleries/{$albumId}/photos");
    }

    public function togglePhoto(array $p): void
{
    $ph = $this->photo->find((int)$p['photoId']);
    if (!$ph) { http_response_code(404); echo 'Bulunamadı'; return; }

    $this->photo->toggle((int)$ph['id']);
    header('Location: /admin/photo-galleries/'.$ph['album_id'].'/photos');
    exit;
}

public function deletePhoto(array $p): void
{
    $ph = $this->photo->find((int)$p['photoId']);
    if (!$ph) { http_response_code(404); echo 'Bulunamadı'; return; }

    $albumId = (int)$ph['album_id'];
    $this->photo->delete((int)$ph['id']);

    header('Location: /admin/photo-galleries/'.$albumId.'/photos');
    exit;
}

public function makePhotoCover(array $p): void
{
    $ph = $this->photo->find((int)$p['photoId']);
    if (!$ph) { http_response_code(404); echo 'Bulunamadı'; return; }

    $this->album->setCover((int)$ph['album_id'], $ph['image_path']);
    header('Location: /admin/photo-galleries/'.$ph['album_id'].'/photos');
    exit;
}


    public function setCover(array $p): void
    {
        // opsiyonel; bir URL verilirse albüm kapak yap
        $this->album->setCover((int)$p['id'], $_POST['cover_path'] ?? '');
        header("Location: /admin/photo-galleries/{$p['id']}/photos");
    }

    private function collectAlbum(array $post,array $files,bool $update=false): array
    {
        $title=trim($post['title']??''); if($title===''){ $_SESSION['flash']='Başlık zorunludur'; header('Location: /admin/photo-galleries/create'); exit; }
        $root=dirname(__DIR__,3); $uploadDir=$root.'/public/uploads/gallery/covers';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $cover=null;
        if(isset($files['cover']) && (int)($files['cover']['error']??4)===UPLOAD_ERR_OK){
            $ext=strtolower(pathinfo($files['cover']['name'],PATHINFO_EXTENSION));
            if(in_array($ext,['png','jpg','jpeg','gif','webp'],true)){
                $target=$uploadDir.'/cover_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['cover']['tmp_name'],$target))
                    $cover='/uploads/gallery/covers/'.basename($target);
            }
        }

        return [
            'sort_order'=>(int)($post['sort_order'] ?? 1),
            'title'=>$title,
            'cover_path'=>$cover,
            'content'=>$post['content'] ?? null,
            'show_on_home'=>isset($post['show_on_home']),
            'is_active'=>isset($post['is_active']),
            'meta_description'=>trim($post['meta_description'] ?? ''),
            'meta_keywords'=>trim($post['meta_keywords'] ?? ''),
        ];
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class SocialSettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/social', ['s' => $s]);
    }

    public function save(): void
    {
        $payload = [
            'facebook_url'  => trim($_POST['facebook_url'] ?? ''),
            'twitter_url'   => trim($_POST['twitter_url'] ?? ''),
            'instagram_url' => trim($_POST['instagram_url'] ?? ''),
            'linkedin_url'  => trim($_POST['linkedin_url'] ?? ''),
            'youtube_url'   => trim($_POST['youtube_url'] ?? ''),
        ];

        // basit URL doğrulama (boş değilse kontrol et)
        foreach ($payload as $k => $v) {
            if ($v !== '' && !filter_var($v, FILTER_VALIDATE_URL)) {
                $_SESSION['flash'] = ucfirst(str_replace('_',' ',$k)).' geçerli bir URL olmalı.';
                header('Location: /admin/settings/social'); return;
            }
        }

        $this->settings->save($payload);
        $_SESSION['flash'] = 'Sosyal medya ayarları güncellendi.';
        header('Location: /admin/settings/social');
    }
}

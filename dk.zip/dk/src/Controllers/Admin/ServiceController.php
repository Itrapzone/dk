<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Service;
use League\Plates\Engine;

class ServiceController
{
    private Engine $view;
    private Service $svc;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->svc  = new Service($c->get('db'));
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1));
        $per =max(1,(int)($_GET['per'] ??10));
        $q   =trim($_GET['q']??'');
        $data=$this->svc->paginate($page,$per,$q);
        echo $this->view->render('admin/services/index',[
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/services/form',['row'=>null]); }

    public function store(): void
    {
        $payload=$this->collect($_POST,$_FILES);
        $id=$this->svc->create($payload);
        $_SESSION['flash']='Hizmet eklendi.'; header('Location: /admin/services/'.$id.'/edit');
    }

    public function edit(array $p): void
    {
        $row=$this->svc->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/services/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id']; $payload=$this->collect($_POST,$_FILES,true);
        $this->svc->update($id,$payload);
        $_SESSION['flash']='Hizmet güncellendi.'; header('Location: /admin/services/'.$id.'/edit');
    }

    public function destroy(array $p): void
    {
        $this->svc->delete((int)$p['id']); $_SESSION['flash']='Hizmet silindi.'; header('Location: /admin/services');
    }

    public function toggle(array $p): void { $this->svc->toggle((int)$p['id']); header('Location: /admin/services'); }

    private function collect(array $post,array $files,bool $isUpdate=false): array
    {
        $root=dirname(__DIR__,3); $uploadDir=$root.'/public/uploads';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $title=trim($post['title']??'');
        if($title===''){ $_SESSION['flash']='Başlık zorunludur.'; header('Location: /admin/services/create'); exit; }

        $slug=trim($post['slug']??'');
        if($slug===''){ $slug=strtolower(preg_replace('~[^a-z0-9]+~','-', iconv('UTF-8','ASCII//TRANSLIT',$title))); }

        $cover=null;
        if(isset($files['cover']) && (int)($files['cover']['error']??4)===UPLOAD_ERR_OK){
            $ext=strtolower(pathinfo($files['cover']['name'],PATHINFO_EXTENSION));
            if(in_array($ext,['png','jpg','jpeg','gif','webp'],true)){
                $target=$uploadDir.'/service_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['cover']['tmp_name'],$target))
                    $cover='/uploads/'.basename($target);
            }
        }

        return [
            'sort_order'=>(int)($post['sort_order']??1),
            'title'=>$title,'slug'=>$slug,'cover_path'=>$cover,
            'content'=>$post['content'] ?? null,
            'meta_description'=>trim($post['meta_description']??'') ?: null,
            'meta_keywords'=>trim($post['meta_keywords']??'') ?: null,
            'is_active'=>isset($post['is_active']),
        ];
    }
}

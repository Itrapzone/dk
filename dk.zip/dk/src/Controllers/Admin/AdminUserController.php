<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\AdminUser;
use League\Plates\Engine;

class AdminUserController
{
    private Engine $view;
    private AdminUser $users;

    public function __construct(private Container $c)
    {
        $this->view=$c->get('view');
        $this->users=new AdminUser($c->get('db'));
    }

    public function index(): void {
        $page=max(1,(int)($_GET['page']??1)); $per=max(1,(int)($_GET['per']??20));
        $q=trim($_GET['q']??'');
        $data=$this->users->paginate($page,$per,$q);
        echo $this->view->render('admin/admins/index',[
            'rows'=>$data['rows'],'page'=>$page,'per'=>$per,'q'=>$q,'total'=>$data['total']
        ]);
    }

    public function create(): void { echo $this->view->render('admin/admins/form',['row'=>null]); }

    public function store(): void {
        $d=$this->collect($_POST,$_FILES);
        if($this->users->findByEmailOrUsername($d['email'],$d['username'])){
            $_SESSION['flash']='Bu e-posta ya da kullanıcı adı kullanımda.'; header('Location: /admin/admins/create'); exit;
        }
        $id=$this->users->create($d);
        $_SESSION['flash']='Yönetici eklendi.'; header("Location: /admin/admins/$id/edit"); exit;
    }

    public function edit(array $p): void {
        $row=$this->users->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/admins/form',['row'=>$row]);
    }

    public function update(array $p): void {
        $id=(int)$p['id']; $d=$this->collect($_POST,$_FILES,true);
        if($this->users->findByEmailOrUsername($d['email'],$d['username'],$id)){
            $_SESSION['flash']='Bu e-posta ya da kullanıcı adı kullanımda.'; header("Location: /admin/admins/$id/edit"); exit;
        }
        $this->users->update($id,$d);
        $_SESSION['flash'] = 'Güncellendi.';
    header('Location: /admin/admins');   // ← listeye yönlendir
    exit;
    }

    public function destroy(array $p): void {
        $this->users->delete((int)$p['id']); $_SESSION['flash']='Silindi.'; header('Location: /admin/admins'); exit;
    }

    public function toggle(array $p): void { $this->users->toggle((int)$p['id']); header('Location: /admin/admins'); exit; }

    private function weakPassword(string $pw): bool {
    // Politika: en az 8 karakter, en az 1 harf + 1 rakam
    if (strlen($pw) < 8) return true;
    if (!preg_match('/[A-Za-z]/', $pw)) return true;
    if (!preg_match('/\d/', $pw)) return true;

    // Kolay tahmin edilen parçalar yasak
    $bad = ['password','qwerty','admin','user','demo','123456','123456789','iloveyou'];
    foreach ($bad as $b) {
        if (stripos($pw, $b) !== false) return true;
    }
    return false;
}


    private function collect(array $post, array $files, bool $isUpdate=false): array
{
    $name = trim($post['name'] ?? '');
    $email = trim($post['email'] ?? '');
    $username = trim($post['username'] ?? '');
    $back = $_SERVER['HTTP_REFERER'] ?? '/admin/admins';

    if ($name === '' || $email === '' || $username === '') {
        $_SESSION['flash'] = 'İsim, e-posta ve kullanıcı adı zorunludur.';
        header('Location: '.$back, true, 303);
        exit;
    }

    // Avatar yükleme (aynı kalsın)
    $root = dirname(__DIR__,3);
    $up   = $root.'/public/uploads/avatars';
    if (!is_dir($up)) mkdir($up, 0775, true);

    $avatar = null;
    if (isset($files['avatar']) && (int)($files['avatar']['error'] ?? 4) === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($files['avatar']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['png','jpg','jpeg','gif','webp'], true)) {
            $target = $up.'/av_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)).'.'.$ext;
            if (move_uploaded_file($files['avatar']['tmp_name'], $target)) {
                $avatar = '/uploads/avatars/'.basename($target);
            }
        }
    }

    // Sadece yeni şifre girildiyse kontrol et ve hashle
    $passwordHash = null;
    $pw = trim($post['password'] ?? '');
    if (!$isUpdate || $pw !== '') {                 // <= kritik: güncellemede boşsa dokunma
        if ($this->weakPassword($pw)) {
            $_SESSION['flash'] = 'Şifre çok zayıf. Min 8 karakter, en az 1 harf ve 1 rakam içermeli.';
            header('Location: '.$back, true, 303);
            exit;
        }
        $passwordHash = password_hash($pw, PASSWORD_DEFAULT);
    }

    return [
        'name'          => $name,
        'email'         => $email,
        'username'      => $username,
        'password_hash' => $passwordHash,   // boş olabilir → update SQL’i zaten koşullu ekliyor
        'avatar_path'   => $avatar,
        'is_active'     => isset($post['is_active']),
        'is_super'      => isset($post['is_super']),
    ];
}

}

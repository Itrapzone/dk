<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\MealMenu;
use League\Plates\Engine;

class MealMenuController
{
    private Engine $view;
    private MealMenu $menu;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->menu = new MealMenu($c->get('db'));
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1));
        $per =max(1,(int)($_GET['per'] ??10));
        $q   =trim($_GET['q']??'');
        $data=$this->menu->paginate($page,$per,$q);
        echo $this->view->render('admin/meal_menus/index',[
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/meal_menus/form',['row'=>null]); }

    public function store(): void
    {
        $payload=$this->collect($_POST,$_FILES);
        $id=$this->menu->create($payload);
        $_SESSION['flash']='Menü eklendi.'; header("Location: /admin/meal-menus/$id/edit");
    }

    public function edit(array $p): void
    {
        $row=$this->menu->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/meal_menus/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id']; $payload=$this->collect($_POST,$_FILES,true);
        $this->menu->update($id,$payload);
        $_SESSION['flash']='Menü güncellendi.'; header("Location: /admin/meal-menus/$id/edit");
    }

    public function destroy(array $p): void
    {
        $this->menu->delete((int)$p['id']); $_SESSION['flash']='Menü silindi.'; header('Location: /admin/meal-menus');
    }

    public function toggle(array $p): void { $this->menu->toggle((int)$p['id']); header('Location: /admin/meal-menus'); }

    private function collect(array $post,array $files,bool $isUpdate=false): array
    {
        $root=dirname(__DIR__,3); $uploadDir=$root.'/public/uploads';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $title=trim($post['title']??'');
        if($title===''){ $_SESSION['flash']='Başlık zorunludur.'; header('Location: /admin/meal-menus/create'); exit; }

        $file=null;
        if(isset($files['file']) && (int)($files['file']['error']??4)===UPLOAD_ERR_OK){
            $ext=strtolower(pathinfo($files['file']['name'],PATHINFO_EXTENSION));
            // pdf veya görsel
            if(in_array($ext,['pdf','png','jpg','jpeg','gif','webp'],true)){
                $target=$uploadDir.'/meal_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['file']['tmp_name'],$target))
                    $file='/uploads/'.basename($target);
            }
        }

        return [
            'sort_order'=>(int)($post['sort_order']??1),
            'title'=>$title,
            'file_path'=>$file,
            'is_active'=>isset($post['is_active']),
        ];
    }
}

<?php
declare(strict_types=1);
namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Language;
use League\Plates\Engine;

class LanguageController
{
    private Engine $view;
    private Language $lang;

    public function __construct(private Container $c) {
        $this->view = $c->get('view');
        $this->lang = new Language($c->get('db'));
    }

    public function index(): void {
        $page = max(1,(int)($_GET['page'] ?? 1));
        $q    = trim($_GET['q'] ?? '');
        $per  = max(1,(int)($_GET['per'] ?? 10));
        $data = $this->lang->paginate($page,$per,$q);
        echo $this->view->render('admin/languages/index', [
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void {
        $countries = ['Türkiye','ABD','Birleşik Krallık','Almanya','Fransa','İtalya','İspanya','Rusya'];
        echo $this->view->render('admin/languages/create', ['countries'=>$countries]);
    }

    public function store(): void {
        $name=trim($_POST['name']??''); if($name===''){$_SESSION['flash']='Dil adı zorunlu.'; header('Location: /admin/languages/create'); return;}
        $code=trim($_POST['code']??''); if($code!=='' && !preg_match('/^[a-z]{2,5}(-[A-Z]{2})?$/',$code)){$_SESSION['flash']='Dil kodu tr, en, en-US gibi olmalı.'; header('Location: /admin/languages/create'); return;}
        $this->lang->create([
            'sort_order'=>(int)($_POST['sort_order']??1),'name'=>$name,
            'country'=>trim($_POST['country']??''),'code'=>$code?:null,
            'is_active'=>isset($_POST['is_active']),'is_default'=>isset($_POST['is_default'])
        ]);
        $_SESSION['flash']='Dil eklendi.'; header('Location: /admin/languages');
    }

    public function edit(array $p): void {
        $row = $this->lang->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        $countries = ['Türkiye','ABD','Birleşik Krallık','Almanya','Fransa','İtalya','İspanya','Rusya'];
        echo $this->view->render('admin/languages/edit', ['row'=>$row,'countries'=>$countries]);
    }

    public function update(array $p): void {
        $id=(int)$p['id']; $name=trim($_POST['name']??''); if($name===''){$_SESSION['flash']='Dil adı zorunlu.'; header("Location: /admin/languages/{$id}/edit"); return;}
        $code=trim($_POST['code']??''); if($code!=='' && !preg_match('/^[a-z]{2,5}(-[A-Z]{2})?$/',$code)){$_SESSION['flash']='Dil kodu tr, en, en-US gibi olmalı.'; header("Location: /admin/languages/{$id}/edit"); return;}
        $this->lang->update($id,[
            'sort_order'=>(int)($_POST['sort_order']??1),'name'=>$name,
            'country'=>trim($_POST['country']??''),'code'=>$code?:null,
            'is_active'=>isset($_POST['is_active']),'is_default'=>isset($_POST['is_default'])
        ]);
        $_SESSION['flash']='Dil güncellendi.'; header('Location: /admin/languages');
    }

    public function destroy(array $p): void {
        $this->lang->delete((int)$p['id']); $_SESSION['flash']='Dil silindi.'; header('Location: /admin/languages');
    }

    public function toggle(array $p): void {
        $this->lang->toggle((int)$p['id']); header('Location: /admin/languages');
    }

    public function makeDefault(array $p): void {
        $this->lang->makeDefault((int)$p['id']); header('Location: /admin/languages');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use League\Plates\Engine;
use PDO;

class DashboardController
{
    private Engine $view;
    private PDO $db;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->db   = $c->get('db');
    }

    public function index(): void
    {
        // (Opsiyonel) Hızlı istatistikler — tablo yoksa patlamasın diye try/catch
        $stats = [];
        foreach ([
            'news' => 'Haberler',
            'events' => 'Etkinlikler',
            'pages' => 'Sayfalar',
            'services' => 'Hizmetler',
            'departments' => 'Eğitim Birimleri',
            'courses' => 'Kurslar',
            'faqs' => 'S.S.S',
            'brands' => 'Markalar',
            'meal_menus' => 'Yemek Menüsü',
            'documents' => 'Belgeler',
            'staff' => 'Eğitim Kadrosu',
            'sliders' => 'Slider',
            'gallery_albums' => 'Foto Albümler',
            'users' => 'Yöneticiler',
        ] as $table => $label) {
            try {
                $count = (int)$this->db->query("SELECT COUNT(*) FROM $table")->fetchColumn();
                $stats[$table] = ['label'=>$label, 'count'=>$count];
            } catch (\Throwable $e) {
                $stats[$table] = ['label'=>$label, 'count'=>null]; // tablo yoksa null bırak
            }
        }

        echo $this->view->render('admin/dashboard', ['stats' => $stats]);
    }
}

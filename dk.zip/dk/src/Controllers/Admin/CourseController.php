<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Course;
use League\Plates\Engine;

class CourseController
{
    private Engine $view;
    private Course $course;

    public function __construct(private Container $c)
    {
        $this->view   = $c->get('view');
        $this->course = new Course($c->get('db'));
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1));
        $per =max(1,(int)($_GET['per'] ??10));
        $q   =trim($_GET['q']??'');
        $data=$this->course->paginate($page,$per,$q);
        echo $this->view->render('admin/courses/index',[
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/courses/form',['row'=>null]); }

    public function store(): void
    {
        $payload=$this->collect($_POST,$_FILES);
        $id=$this->course->create($payload);
        $_SESSION['flash']='Kurs eklendi.'; header('Location: /admin/courses/'.$id.'/edit');
    }

    public function edit(array $p): void
    {
        $row=$this->course->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/courses/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id']; $payload=$this->collect($_POST,$_FILES,true);
        $this->course->update($id,$payload);
        $_SESSION['flash']='Kurs güncellendi.'; header('Location: /admin/courses/'.$id.'/edit');
    }

    public function destroy(array $p): void
    {
        $this->course->delete((int)$p['id']); $_SESSION['flash']='Kurs silindi.'; header('Location: /admin/courses');
    }

    public function toggle(array $p): void { $this->course->toggle((int)$p['id']); header('Location: /admin/courses'); }

    private function collect(array $post,array $files,bool $isUpdate=false): array
    {
        $root=dirname(__DIR__,3); $uploadDir=$root.'/public/uploads';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $title=trim($post['title']??'');
        if($title===''){ $_SESSION['flash']='Başlık zorunludur.'; header('Location: /admin/courses/create'); exit; }

        $slug=trim($post['slug']??'');
        if($slug===''){ $slug=strtolower(preg_replace('~[^a-z0-9]+~','-', iconv('UTF-8','ASCII//TRANSLIT',$title))); }

        $cover=null;
        if(isset($files['cover']) && (int)($files['cover']['error']??4)===UPLOAD_ERR_OK){
            $ext=strtolower(pathinfo($files['cover']['name'],PATHINFO_EXTENSION));
            if(in_array($ext,['png','jpg','jpeg','gif','webp'],true)){
                $target=$uploadDir.'/course_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['cover']['tmp_name'],$target))
                    $cover='/uploads/'.basename($target);
            }
        }

        return [
            'sort_order'=>(int)($post['sort_order']??1),
            'title'=>$title,'slug'=>$slug,'cover_path'=>$cover,
            'show_on_home'=>isset($post['show_on_home']),
            'is_active'=>isset($post['is_active']),
            'content'=>$post['content'] ?? null,
            'meta_description'=>trim($post['meta_description']??'') ?: null,
            'meta_keywords'=>trim($post['meta_keywords']??'') ?: null,
        ];
    }
}

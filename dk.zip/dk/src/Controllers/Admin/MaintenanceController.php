<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class MaintenanceController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view     = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/maintenance', ['s' => $s]);
    }

    public function save(): void
    {
        $date = trim($_POST['maintenance_open_date'] ?? '');
        $time = trim($_POST['maintenance_open_time'] ?? '');

        // basit doğrulama
        if ($date !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = '';
        if ($time !== '' && !preg_match('/^\d{2}:\d{2}$/', $time))       $time = '';

        $payload = [
            'maintenance_open_date' => $date,
            'maintenance_open_time' => $time,
            'maintenance_title'     => trim($_POST['maintenance_title'] ?? ''),
            'maintenance_message'   => trim($_POST['maintenance_message'] ?? ''),
        ];
        $this->settings->save($payload);

        $_SESSION['flash'] = 'Bakım modu ayarları kaydedildi.';
        header('Location: /admin/settings/maintenance');
    }
}

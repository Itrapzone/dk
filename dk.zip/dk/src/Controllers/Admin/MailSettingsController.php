<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class MailSettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/mail', ['s' => $s]);
    }

    public function save(): void
    {
        $host   = trim($_POST['smtp_host'] ?? '');
        $port   = (int)($_POST['smtp_port'] ?? 465);
        $secure = strtolower(trim($_POST['smtp_secure'] ?? 'ssl')); // ssl|tls|none
        $user   = trim($_POST['smtp_user'] ?? '');
        $pass   = trim($_POST['smtp_pass'] ?? '');
        $active = isset($_POST['smtp_active']) ? '1' : '0';
        $to     = trim($_POST['smtp_to'] ?? '');

        if (!in_array($secure, ['ssl','tls','none'], true)) $secure = 'ssl';
        if ($port < 1 || $port > 65535) $port = 465;
        if ($to !== '' && !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = 'Geçerli bir “Mesaj Alıcı E-Posta Adresi” girin.';
            header('Location: /admin/settings/mail'); return;
        }
        if ($user !== '' && !filter_var($user, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = 'Geçerli bir SMTP Email girin.';
            header('Location: /admin/settings/mail'); return;
        }

        // Parola boş bırakılırsa mevcut değeri koru
        $payload = [
            'smtp_host'   => $host,
            'smtp_port'   => (string)$port,
            'smtp_secure' => $secure,
            'smtp_user'   => $user,
            'smtp_active' => $active,
            'smtp_to'     => $to,
        ];
        if ($pass !== '') { $payload['smtp_pass'] = $pass; }

        $this->settings->save($payload);
        $_SESSION['flash'] = 'Mail ayarları güncellendi.';
        header('Location: /admin/settings/mail');
    }
}

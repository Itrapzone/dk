<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Popup;
use League\Plates\Engine;

class PopupController
{
    private Engine $view;
    private Popup $popup;

    public function __construct(private Container $c)
    {
        $this->view  = $c->get('view');
        $this->popup = new Popup($c->get('db'));
    }

    public function show(): void
    {
        $data = $this->popup->get();
        echo $this->view->render('admin/settings/popup', ['p' => $data]);
    }

    public function save(): void
    {
        $root = dirname(__DIR__, 3);
        $uploadDir = $root . '/public/uploads';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0775, true);

        $imagePath = null;
        if (isset($_FILES['image']) && (int)($_FILES['image']['error'] ?? 4) === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['png','jpg','jpeg','gif','webp','svg'], true)) {
                $target = $uploadDir.'/popup_'.date('Ymd_His').'_'.bin2hex(random_bytes(3)).'.'.$ext;
                if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
                    $imagePath = '/uploads/'.basename($target);
                }
            }
        }

        $payload = [
            'title'        => trim($_POST['title'] ?? ''),
            'url'          => trim($_POST['url'] ?? ''),
            'target_blank' => isset($_POST['target_blank']),
            'image_path'   => $imagePath, // null ise eski korunur
            'is_active'    => isset($_POST['is_active']),
        ];

        $this->popup->save($payload);
        $_SESSION['flash'] = 'Açılır mesaj güncellendi.';
        header('Location: /admin/settings/popup');
    }
}

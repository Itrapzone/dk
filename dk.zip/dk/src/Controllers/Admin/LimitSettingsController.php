<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class LimitSettingsController
{
    private Engine $view;
    private Settings $settings;

    /** Anahtar haritası: [etiket, cols_key, per_key] */
    private array $items = [
        ['Belgelerimiz',          'cols_belgeler',         'per_belgeler'],
        ['Eğitim Kadromuz',       'cols_kadro',            'per_kadro'],
        ['Marka Ortaklıklarımız', 'cols_marka_ortak',      'per_marka_ortak'],
        ['Foto Galeri',           'cols_fotogaleri',       'per_fotogaleri'],
        ['Video Galeri',          'cols_videogaleri',      'per_videogaleri'],
        ['Haberler',              'cols_haberler',         'per_haberler'],
        ['Ziyaretçi Yorumları',   'cols_yorumlar',         'per_yorumlar'],
        ['Dökümanlar',            'cols_dokumanlar',       'per_dokumanlar'],
        ['Hizmetlerimiz',         'cols_hizmetler',        'per_hizmetler'],
        ['Eğitim Birimlerimiz',   'cols_egitim_birimleri', 'per_egitim_birimleri'],
        ['Kurslarımız',           'cols_kurslar',          'per_kurslar'],
        ['Şubelerimiz',           'cols_subeler',          'per_subeler'],
        ['Etkinlikler',           'cols_etkinlikler',      'per_etkinlikler'],
        ['Yemek Menüsü',          'cols_yemek_menusu',     'per_yemek_menusu'],
    ];

    public function __construct(private Container $c)
    {
        $this->view     = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/limits', ['s' => $s, 'items' => $this->items]);
    }

    public function save(): void
    {
        $payload = [];
        foreach ($this->items as [$label, $colsKey, $perKey]) {
            // kolon 1..6 arası
            $cols = (int)($_POST[$colsKey] ?? 3);
            if ($cols < 1 || $cols > 6) { $cols = 3; }
            // per-page pozitif
            $per  = (int)($_POST[$perKey] ?? 12);
            if ($per < 1) { $per = 12; }

            $payload[$colsKey] = (string)$cols;
            $payload[$perKey]  = (string)$per;
        }
        $this->settings->save($payload);
        $_SESSION['flash'] = 'Kolon ve sayfalama limitleri güncellendi.';
        header('Location: /admin/settings/limits');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class SettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function general(): void
    {
        $data = $this->settings->getAll();
        echo $this->view->render('admin/settings/general', ['s' => $data]);
    }

    public function saveGeneral(): void
    {
        // upload klasörü
        $root = dirname(__DIR__, 3);
        $uploadDir = $root . '/public/uploads';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0775, true);

        $payload = [
            'site_name'          => trim($_POST['site_name'] ?? ''),
            'contact_email'      => trim($_POST['contact_email'] ?? ''),
            'phone'              => trim($_POST['phone'] ?? ''),
            'address'            => trim($_POST['address'] ?? ''),
            'theme_color_1'      => trim($_POST['theme_color_1'] ?? '#80091C'),
            'theme_color_2'      => trim($_POST['theme_color_2'] ?? '#000000'),
            'theme_color_3'      => trim($_POST['theme_color_3'] ?? '#f7f7f7'),
            'site_url'           => trim($_POST['site_url'] ?? ''),
            'homepage_title'     => trim($_POST['homepage_title'] ?? ''),
            'meta_description'   => trim($_POST['meta_description'] ?? ''),
            'seo_keywords'       => trim($_POST['seo_keywords'] ?? ''), // etiketleri virgülle tutuyoruz
            'video_youtube_id'   => trim($_POST['video_youtube_id'] ?? ''),
            'protected_password' => trim($_POST['protected_password'] ?? ''),
            'admin_slug'         => preg_replace('~[^a-z0-9\-]~', '', strtolower(trim($_POST['admin_slug'] ?? 'yonetim'))),
            'copyright_text'     => trim($_POST['copyright_text'] ?? ''),
        ];

        // Basit güvenli yükleme yardımcıları
        $saveUpload = function (string $input, array $allowExt = ['png','jpg','jpeg','gif','svg','ico']) use ($uploadDir) {
            if (!isset($_FILES[$input]) || (int)($_FILES[$input]['error'] ?? 4) !== UPLOAD_ERR_OK) return null;
            $name = $_FILES[$input]['name'];
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowExt, true)) return null;
            $target = $uploadDir . '/' . $input . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            if (move_uploaded_file($_FILES[$input]['tmp_name'], $target)) {
                return '/uploads/' . basename($target);
            }
            return null;
        };

        if ($p = $saveUpload('logo'))        $payload['logo_path']      = $p;
        if ($p = $saveUpload('mail_logo'))   $payload['mail_logo_path'] = $p;
        if ($p = $saveUpload('favicon', ['png','jpg','jpeg','ico','svg'])) $payload['favicon_path'] = $p;

        $this->settings->save($payload);
        $_SESSION['flash'] = 'Ayarlar kaydedildi.';
        header('Location: /admin/settings/general');
    }
}

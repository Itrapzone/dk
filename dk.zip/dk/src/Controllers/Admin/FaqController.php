<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Faq;
use League\Plates\Engine;

class FaqController
{
    private Engine $view;
    private Faq $faq;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->faq  = new Faq($c->get('db'));
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1));
        $per =max(1,(int)($_GET['per'] ??10));
        $q   =trim($_GET['q']??'');
        $data=$this->faq->paginate($page,$per,$q);
        echo $this->view->render('admin/faqs/index',[
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/faqs/form',['row'=>null]); }

    public function store(): void
    {
        $question=trim($_POST['question'] ?? '');
        if($question===''){ $_SESSION['flash']='Soru adı zorunludur.'; header('Location: /admin/faqs/create'); exit; }
        $this->faq->create($this->collect($_POST));
        $_SESSION['flash']='Soru eklendi.'; header('Location: /admin/faqs');
    }

    public function edit(array $p): void
    {
        $row=$this->faq->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/faqs/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id'];
        $question=trim($_POST['question'] ?? '');
        if($question===''){ $_SESSION['flash']='Soru adı zorunludur.'; header("Location: /admin/faqs/$id/edit"); exit; }
        $this->faq->update($id,$this->collect($_POST));
        $_SESSION['flash']='Soru güncellendi.'; header("Location: /admin/faqs/$id/edit");
    }

    public function destroy(array $p): void
    {
        $this->faq->delete((int)$p['id']); $_SESSION['flash']='Soru silindi.'; header('Location: /admin/faqs');
    }

    public function toggle(array $p): void { $this->faq->toggle((int)$p['id']); header('Location: /admin/faqs'); }

    private function collect(array $post): array
    {
        return [
            'sort_order'=>(int)($post['sort_order']??1),
            'question'=>trim($post['question']??''),
            'answer'=>$post['answer'] ?? null,
            'is_active'=> isset($post['is_active']),
        ];
    }
}

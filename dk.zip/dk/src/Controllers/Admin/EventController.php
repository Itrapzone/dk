<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Event;
use League\Plates\Engine;

class EventController
{
    private Engine $view;
    private Event $event;

    public function __construct(private Container $c)
    {
        $this->view  = $c->get('view');
        $this->event = new Event($c->get('db'));
    }

    public function index(): void
    {
        $page = max(1,(int)($_GET['page'] ?? 1));
        $per  = max(1,(int)($_GET['per'] ?? 10));
        $q    = trim($_GET['q'] ?? '');
        $data = $this->event->paginate($page,$per,$q);
        echo $this->view->render('admin/events/index', [
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void
    {
        echo $this->view->render('admin/events/form', ['row'=>null]);
    }

    public function store(): void
    {
        $payload = $this->collect($_POST, $_FILES);
        $id = $this->event->create($payload);
        $_SESSION['flash'] = 'Etkinlik eklendi.';
        header('Location: /admin/events/'.$id.'/edit');
    }

    public function edit(array $p): void
    {
        $row = $this->event->find((int)$p['id']);
        if(!$row){ http_response_code(404); echo 'Bulunamadı'; return; }
        echo $this->view->render('admin/events/form', ['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id = (int)$p['id'];
        $payload = $this->collect($_POST, $_FILES, true);
        $this->event->update($id, $payload);
        $_SESSION['flash'] = 'Etkinlik güncellendi.';
        header('Location: /admin/events/'.$id.'/edit');
    }

    public function destroy(array $p): void
    {
        $this->event->delete((int)$p['id']);
        $_SESSION['flash'] = 'Etkinlik silindi.';
        header('Location: /admin/events');
    }

    public function toggle(array $p): void
    {
        $this->event->toggle((int)$p['id']);
        header('Location: /admin/events');
    }

    private function collect(array $post, array $files, bool $isUpdate=false): array
    {
        $root = dirname(__DIR__, 3); $uploadDir = $root.'/public/uploads';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $title = trim($post['title'] ?? '');
        if($title===''){ $_SESSION['flash']='Başlık zorunlu.'; header('Location: /admin/events/create'); exit; }

        $slug = trim($post['slug'] ?? '');
        if($slug===''){ $slug = strtolower(preg_replace('~[^a-z0-9]+~','-', iconv('UTF-8','ASCII//TRANSLIT',$title))); }

        $cover = null;
        if(isset($files['cover']) && (int)($files['cover']['error'] ?? 4)===UPLOAD_ERR_OK){
            $ext = strtolower(pathinfo($files['cover']['name'], PATHINFO_EXTENSION));
            if(in_array($ext,['png','jpg','jpeg','gif','webp'],true)){
                $target = $uploadDir.'/event_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['cover']['tmp_name'],$target))
                    $cover = '/uploads/'.basename($target);
            }
        }

        return [
            'title' => $title,
            'slug'  => $slug,
            'start_date' => $post['start_date'] ?: null,
            'end_date'   => $post['end_date']   ?: null,
            'location'   => trim($post['location'] ?? '') ?: null,
            'map_embed'  => trim($post['map_embed'] ?? '') ?: null,
            'cover_path' => $cover, // update’de null ise korunur
            'content'    => $post['content'] ?? null,
            'meta_description' => trim($post['meta_description'] ?? '') ?: null,
            'meta_keywords'    => trim($post['meta_keywords'] ?? '') ?: null,
            'is_active'  => isset($post['is_active']),
        ];
    }
}

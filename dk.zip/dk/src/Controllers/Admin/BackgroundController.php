<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class BackgroundController
{
    private Engine $view;
    private Settings $settings;

    /** input name => settings key */
    private array $map = [
        'bg_footer'            => 'bg_footer',
        'bg_istatistik'        => 'bg_istatistik',
        'bg_tanitim_video'     => 'bg_tanitim_video',
        'bg_detay_fotogaleri'  => 'bg_detay_fotogaleri',
        'bg_detay_videogaleri' => 'bg_detay_videogaleri',
    ];

    public function __construct(private Container $c)
    {
        $this->view     = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/backgrounds', ['s' => $s]);
    }

    public function save(): void
    {
        $root = dirname(__DIR__, 3);
        $uploadDir = $root . '/public/uploads';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0775, true);

        $allow = ['png','jpg','jpeg','gif','webp','svg'];
        $payload = [];

        foreach ($this->map as $input => $key) {
            if (!isset($_FILES[$input]) || (int)($_FILES[$input]['error'] ?? 4) !== UPLOAD_ERR_OK) continue;
            $ext = strtolower(pathinfo($_FILES[$input]['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $allow, true)) continue;

            $fname = $input . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
            $target = $uploadDir . '/' . $fname;
            if (move_uploaded_file($_FILES[$input]['tmp_name'], $target)) {
                $payload[$key] = '/uploads/' . $fname;
            }
        }

        if ($payload) {
            $this->settings->save($payload);
            $_SESSION['flash'] = 'Arka plan görselleri güncellendi.';
        } else {
            $_SESSION['flash'] = 'Güncellenecek görsel seçilmedi.';
        }

        header('Location: /admin/settings/backgrounds');
    }
}

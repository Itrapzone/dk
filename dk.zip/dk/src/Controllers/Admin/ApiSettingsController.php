<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class ApiSettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/api', ['s' => $s]);
    }

    public function save(): void
    {
        // ham kodlar – filtrelemeden saklıyoruz (bilerek),
        // çünkü <script>, <meta>, <iframe> içerecekler.
        $payload = [
            'code_whatsapp'   => $_POST['code_whatsapp']   ?? '',
            'code_ga'         => $_POST['code_ga']         ?? '',
            'code_webmaster'  => $_POST['code_webmaster']  ?? '',
            'code_map_embed'  => $_POST['code_map_embed']  ?? '',
            'code_livechat'   => $_POST['code_livechat']   ?? '',
        ];
        $this->settings->save($payload);
        $_SESSION['flash'] = 'API ayarları güncellendi.';
        header('Location: /admin/settings/api');
    }
}

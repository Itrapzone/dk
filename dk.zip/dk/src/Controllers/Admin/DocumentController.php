<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Document;
use League\Plates\Engine;

class DocumentController
{
    private Engine $view;
    private Document $doc;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->doc  = new Document($c->get('db'));
    }

    public function index(): void
    {
        $page=max(1,(int)($_GET['page']??1));
        $per =max(1,(int)($_GET['per'] ??10));
        $q   =trim($_GET['q']??'');
        $data=$this->doc->paginate($page,$per,$q);
        echo $this->view->render('admin/documents/index',[
            'rows'=>$data['rows'],'total'=>$data['total'],'page'=>$page,'per'=>$per,'q'=>$q
        ]);
    }

    public function create(): void { echo $this->view->render('admin/documents/form',['row'=>null]); }

    public function store(): void
    {
        $payload=$this->collect($_POST,$_FILES);
        $id=$this->doc->create($payload);
        $_SESSION['flash']='Belge eklendi.'; header("Location: /admin/documents/$id/edit");
    }

    public function edit(array $p): void
    {
        $row=$this->doc->find((int)$p['id']); if(!$row){http_response_code(404); echo 'Bulunamadı'; return;}
        echo $this->view->render('admin/documents/form',['row'=>$row]);
    }

    public function update(array $p): void
    {
        $id=(int)$p['id']; $payload=$this->collect($_POST,$_FILES,true);
        $this->doc->update($id,$payload);
        $_SESSION['flash']='Belge güncellendi.'; header("Location: /admin/documents/$id/edit");
    }

    public function destroy(array $p): void
    {
        $this->doc->delete((int)$p['id']); $_SESSION['flash']='Belge silindi.'; header('Location: /admin/documents');
    }

    public function toggle(array $p): void { $this->doc->toggle((int)$p['id']); header('Location: /admin/documents'); }

    private function collect(array $post,array $files,bool $isUpdate=false): array
    {
        $root=dirname(__DIR__,3); $uploadDir=$root.'/public/uploads';
        if(!is_dir($uploadDir)) mkdir($uploadDir,0775,true);

        $title=trim($post['title']??'');
        if($title===''){ $_SESSION['flash']='Başlık zorunludur.'; header('Location: /admin/documents/create'); exit; }

        $file=null; $mime=null;
        if(isset($files['file']) && (int)($files['file']['error']??4)===UPLOAD_ERR_OK){
            $ext=strtolower(pathinfo($files['file']['name'],PATHINFO_EXTENSION));
            $allowed=['pdf','doc','docx','xls','xlsx','ppt','pptx','png','jpg','jpeg','gif','webp'];
            if(in_array($ext,$allowed,true)){
                $target=$uploadDir.'/doc_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
                if(move_uploaded_file($files['file']['tmp_name'],$target)){
                    $file='/uploads/'.basename($target);
                    $mime=$files['file']['type'] ?? null;
                }
            }
        }

        return [
            'sort_order'=>(int)($post['sort_order']??1),
            'title'=>$title,
            'file_path'=>$file,
            'mime_type'=>$mime,
            'is_active'=>isset($post['is_active']),
        ];
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class ModuleSettingsController
{
    private Engine $view;
    private Settings $settings;

    /** Modül anahtarları */
    private array $keys = [
        // Anasayfa
        'home_slider_info','home_egitim_birimleri','home_hakkimizda','home_kurslar',
        'home_istatistik','home_kadro','home_fotogaleri','home_yorumlar',
        'home_paketler','home_tanitim_video','home_referanslar','home_haberler',
        // Diğer
        'site_loading','url_html_suffix','force_ssl','mod_bursluluk','mod_on_kayit',
        'mod_is_basvurusu','mod_detay_fotogaleri','mod_detay_videogaleri','base_in_subdir','site_maintenance',
    ];

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/modules', ['s' => $s]);
    }

    public function save(): void
    {
        $payload = [];
        foreach ($this->keys as $k) {
            $payload[$k] = isset($_POST[$k]) ? '1' : '0';
        }
        $this->settings->save($payload);

        $_SESSION['flash'] = 'Modül ayarları güncellendi.';
        header('Location: /admin/settings/modules');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\Container;
use App\Models\Settings;
use League\Plates\Engine;

class SmsSettingsController
{
    private Engine $view;
    private Settings $settings;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->settings = new Settings($c->get('db'));
    }

    public function show(): void
    {
        $s = $this->settings->getAll();
        echo $this->view->render('admin/settings/sms', ['s' => $s]);
    }

    public function save(): void
    {
        $url   = trim($_POST['sms_post_url'] ?? '');
        $user  = trim($_POST['sms_user'] ?? '');
        $sec   = trim($_POST['sms_secret'] ?? '');
        $title = trim($_POST['sms_title'] ?? '');
        $to    = preg_replace('/\s+/', '', trim($_POST['sms_to'] ?? ''));
        $act   = isset($_POST['sms_active']) ? '1' : '0';

        if ($url !== '' && !filter_var($url, FILTER_VALIDATE_URL)) {
            $_SESSION['flash'] = 'Geçerli bir Post URL girin.'; header('Location: /admin/settings/sms'); return;
        }
        if ($to !== '' && !preg_match('/^\+?\d{8,15}$/', $to)) {
            $_SESSION['flash'] = 'Alıcı telefon numarası 8-15 haneli olmalı.'; header('Location: /admin/settings/sms'); return;
        }

        $payload = [
            'sms_post_url' => $url,
            'sms_user'     => $user,
            'sms_title'    => $title,
            'sms_active'   => $act,
            'sms_to'       => $to,
        ];
        // secret boş bırakılırsa mevcut saklansın
        if ($sec !== '') $payload['sms_secret'] = $sec;

        $this->settings->save($payload);
        $_SESSION['flash'] = 'SMS ayarları güncellendi.';
        header('Location: /admin/settings/sms');
    }
}

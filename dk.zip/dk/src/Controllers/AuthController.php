<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Container;
use League\Plates\Engine;
use PDO;

class AuthController
{
    private Engine $view;
    private PDO $db;

    public function __construct(private Container $c)
    {
        $this->view = $c->get('view');
        $this->db   = $c->get('db');
    }

    public function showLogin(): void
    {
        // Oturum açık ise admin ana sayfaya yönlendir
        if (!empty($_SESSION['user'])) {
            header('Location: /admin/news', true, 303);
            exit;
        }

        // (İsteğe bağlı) flash mesajını gönder
        $flash = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);

        echo $this->view->render('auth/login', [
            'isBypass' => false,   // bypass kapalı
            'message'  => $flash,
        ]);
    }

    public function login(array $params = []): void
    {
        $identity = trim($_POST['identity'] ?? ($_POST['email'] ?? ($_POST['username'] ?? '')));
        $password = (string)($_POST['password'] ?? '');

        if ($identity === '' || $password === '') {
            $_SESSION['flash'] = 'Bilgileri eksiksiz giriniz.';
            header('Location: /login', true, 303);
            exit;
        }

        // Aktif kullanıcıyı çek
        $st = $this->db->prepare(
            "SELECT * FROM users WHERE (email = :id OR username = :id) AND is_active = 1 LIMIT 1"
        );
        $st->execute([':id' => $identity]);
        $user = $st->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $_SESSION['flash'] = 'Kullanıcı bulunamadı ya da pasif.';
            header('Location: /login', true, 303);
            exit;
        }

        // BCRYPT doğrulaması
        if (empty($user['password_hash']) || !password_verify($password, $user['password_hash'])) {
            $_SESSION['flash'] = 'Hatalı kullanıcı bilgisi.';
            header('Location: /login', true, 303);
            exit;
        }

        // Başarılı giriş
        $_SESSION['user'] = [
            'id'       => (int)$user['id'],
            'name'     => $user['name'] ?? '',
            'email'    => $user['email'] ?? '',
            'username' => $user['username'] ?? '',
            'is_super' => (int)($user['is_super'] ?? 0),
        ];

        header('Location: /admin', true, 303);
        exit;
    }

    public function logout(): void
    {
        unset($_SESSION['user']);
        session_regenerate_id(true);
        header('Location: /login', true, 303);
        exit;
    }
}

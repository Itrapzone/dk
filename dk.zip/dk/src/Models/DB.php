<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class DB
{
    public static function fromEnv(): PDO
    {
        $driver = $_ENV['DB_DRIVER'] ?? 'sqlite';

        if ($driver === 'mysql') {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                $_ENV['DB_HOST'] ?? '127.0.0.1',
                $_ENV['DB_PORT'] ?? '3306',
                $_ENV['DB_DATABASE'] ?? 'okulsite'
            );
            $pdo = new PDO($dsn, $_ENV['DB_USERNAME'] ?? 'root', $_ENV['DB_PASSWORD'] ?? '');
        } else {
            $root = dirname(__DIR__, 2);
            $dbPath = $_ENV['DB_DATABASE'] ?? ($root . '/okulsite.sqlite');
            if (!str_starts_with($dbPath, '/') && !preg_match('#^[A-Za-z]:(\\\\|/)#', $dbPath)) {
                $dbPath = $root . '/' . ltrim($dbPath, '/');
            }
            $dsn = 'sqlite:' . $dbPath;
            $pdo = new PDO($dsn);
        }

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    }
}

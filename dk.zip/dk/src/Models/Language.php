<?php
declare(strict_types=1);
namespace App\Models;

use PDO;

class Language
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS languages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            name TEXT NOT NULL,
            country TEXT,
            code TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            is_default INTEGER NOT NULL DEFAULT 0,
            created_at DATETIME, updated_at DATETIME
          );
        ");
    }

    public function create(array $d): int {
        if (!empty($d['is_default'])) $this->db->exec("UPDATE languages SET is_default=0");
        $st=$this->db->prepare("INSERT INTO languages(sort_order,name,country,code,is_active,is_default,created_at,updated_at)
          VALUES(:sort,:name,:country,:code,:active,:def,datetime('now'),datetime('now'))");
        $st->execute([
            ':sort'=>(int)($d['sort_order']??1), ':name'=>$d['name'],
            ':country'=>$d['country']??null, ':code'=>$d['code']??null,
            ':active'=>!empty($d['is_active'])?1:0, ':def'=>!empty($d['is_default'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off = ($page-1)*$per;
        $where = $q!=='' ? "WHERE name LIKE :q OR code LIKE :q OR country LIKE :q" : "";
        $count = $this->db->prepare("SELECT COUNT(*) FROM languages $where");
        if($q!=='') $count->bindValue(':q','%'.$q.'%');
        $count->execute(); $total=(int)$count->fetchColumn();

        $sql = "SELECT * FROM languages $where ORDER BY sort_order ASC, id ASC LIMIT :per OFFSET :off";
        $st = $this->db->prepare($sql);
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();
        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM languages WHERE id=?"); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function update(int $id,array $d): void {
        if (!empty($d['is_default'])) $this->db->exec("UPDATE languages SET is_default=0");
        $st=$this->db->prepare("UPDATE languages SET sort_order=:sort,name=:name,country=:country,code=:code,
                 is_active=:active,is_default=:def,updated_at=datetime('now') WHERE id=:id");
        $st->execute([
            ':id'=>$id, ':sort'=>(int)($d['sort_order']??1), ':name'=>$d['name'],
            ':country'=>$d['country']??null, ':code'=>$d['code']??null,
            ':active'=>!empty($d['is_active'])?1:0, ':def'=>!empty($d['is_default'])?1:0
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM languages WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE languages SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }

    public function makeDefault(int $id): void {
        $this->db->beginTransaction();
        $this->db->exec("UPDATE languages SET is_default=0");
        $st=$this->db->prepare("UPDATE languages SET is_default=1, is_active=1 WHERE id=?");
        $st->execute([$id]);
        $this->db->commit();
    }
}

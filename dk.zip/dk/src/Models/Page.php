<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Page
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS pages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT,
            section TEXT,              -- 'Bağlantı Sayfası' (ör. Genel / Hakkımızda vs.)
            cover_path TEXT,           -- Sayfa resmi
            show_on_home INTEGER DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            content TEXT,
            meta_description TEXT,
            meta_keywords TEXT,
            created_at DATETIME,
            updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_pages_active ON pages(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off = ($page-1)*$per;
        $where = $q!=='' ? "WHERE title LIKE :q OR section LIKE :q" : "";
        $cnt = $this->db->prepare("SELECT COUNT(*) FROM pages $where");
        if ($q!=='') $cnt->bindValue(':q','%'.$q.'%');
        $cnt->execute(); $total = (int)$cnt->fetchColumn();

        $sql = "SELECT * FROM pages $where ORDER BY id DESC LIMIT :per OFFSET :off";
        $st  = $this->db->prepare($sql);
        if ($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();
        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM pages WHERE id=?"); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("
          INSERT INTO pages(title,slug,section,cover_path,show_on_home,is_active,content,
                            meta_description,meta_keywords,created_at,updated_at)
          VALUES(:title,:slug,:section,:cover,:home,:act,:content,:md,:mk,datetime('now'),datetime('now'))
        ");
        $st->execute([
          ':title'=>$d['title'], ':slug'=>$d['slug'], ':section'=>$d['section'] ?? null,
          ':cover'=>$d['cover_path'] ?? null, ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0, ':content'=>$d['content'] ?? null,
          ':md'=>$d['meta_description'] ?? null, ':mk'=>$d['meta_keywords'] ?? null,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("
          UPDATE pages SET title=:title, slug=:slug, section=:section,
            cover_path=COALESCE(:cover, cover_path), show_on_home=:home,
            is_active=:act, content=:content, meta_description=:md, meta_keywords=:mk,
            updated_at=datetime('now') WHERE id=:id
        ");
        $st->execute([
          ':id'=>$id, ':title'=>$d['title'], ':slug'=>$d['slug'], ':section'=>$d['section'] ?? null,
          ':cover'=>$d['cover_path'] ?? null, ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0, ':content'=>$d['content'] ?? null,
          ':md'=>$d['meta_description'] ?? null, ':mk'=>$d['meta_keywords'] ?? null,
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM pages WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE pages SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Service
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            title TEXT NOT NULL,
            slug TEXT,
            cover_path TEXT,
            content TEXT,
            meta_description TEXT,
            meta_keywords TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME,
            updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_services_active ON services(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off = ($page-1)*$per;
        $where = $q!=='' ? "WHERE title LIKE :q" : "";
        $cnt = $this->db->prepare("SELECT COUNT(*) FROM services $where");
        if ($q!=='') $cnt->bindValue(':q','%'.$q.'%');
        $cnt->execute(); $total = (int)$cnt->fetchColumn();

        $sql = "SELECT * FROM services $where ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off";
        $st  = $this->db->prepare($sql);
        if ($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();
        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM services WHERE id=?"); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("
          INSERT INTO services(sort_order,title,slug,cover_path,content,meta_description,meta_keywords,is_active,created_at,updated_at)
          VALUES(:sort,:title,:slug,:cover,:content,:md,:mk,:act,datetime('now'),datetime('now'))
        ");
        $st->execute([
          ':sort'=>(int)($d['sort_order']??1), ':title'=>$d['title'], ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null, ':content'=>$d['content']??null,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("
          UPDATE services SET sort_order=:sort, title=:title, slug=:slug,
            cover_path=COALESCE(:cover, cover_path), content=:content,
            meta_description=:md, meta_keywords=:mk, is_active=:act,
            updated_at=datetime('now') WHERE id=:id
        ");
        $st->execute([
          ':id'=>$id, ':sort'=>(int)($d['sort_order']??1), ':title'=>$d['title'], ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null, ':content'=>$d['content']??null,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM services WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE services SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

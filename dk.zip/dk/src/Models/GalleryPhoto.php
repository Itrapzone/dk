<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class GalleryPhoto
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS gallery_photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            album_id INTEGER NOT NULL,
            sort_order INTEGER NOT NULL DEFAULT 1,
            image_path TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME, updated_at DATETIME,
            FOREIGN KEY(album_id) REFERENCES gallery_albums(id) ON DELETE CASCADE
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_gal_photos_album ON gallery_photos(album_id)");
    }

    public function allByAlbum(int $albumId): array {
        $st=$this->db->prepare("SELECT * FROM gallery_photos WHERE album_id=? ORDER BY sort_order ASC, id DESC");
        $st->execute([$albumId]); return $st->fetchAll(PDO::FETCH_ASSOC);
    }

    public function add(int $albumId,string $path,int $sort=1): int {
        $st=$this->db->prepare("INSERT INTO gallery_photos
          (album_id,sort_order,image_path,is_active,created_at,updated_at)
          VALUES(:a,:s,:p,1,datetime('now'),datetime('now'))");
        $st->execute([':a'=>$albumId, ':s'=>$sort, ':p'=>$path]);
        return (int)$this->db->lastInsertId();
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM gallery_photos WHERE id=?");
        $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE gallery_photos SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }

    public function delete(int $id): void {
        $this->db->prepare("DELETE FROM gallery_photos WHERE id=?")->execute([$id]);
    }
}

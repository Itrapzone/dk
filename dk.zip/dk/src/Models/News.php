<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class News
{
    public function __construct(private PDO $db)
    {
        // Tablo yoksa yeni şema ile oluştur
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS news (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            title TEXT NOT NULL,
            slug TEXT,
            cover_path TEXT,
            content TEXT,
            show_on_home INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            meta_description TEXT,
            meta_keywords TEXT,
            created_at DATETIME,
            updated_at DATETIME
          );
        ");

        $this->ensureColumns();   // <- eski tabloları yükselt
        $this->createIndexes();   // <- sadece mevcut kolonlarda indeks aç
    }

    private function columnExists(string $table, string $column): bool
    {
        $st = $this->db->query("PRAGMA table_info($table)");
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if (strcasecmp($row['name'], $column) === 0) return true;
        }
        return false;
    }

   private function ensureColumns(): void
{
    $cols = [
        'sort_order'       => "INTEGER NOT NULL DEFAULT 1",
        'slug'             => "TEXT",
        'cover_path'       => "TEXT",
        'content'          => "TEXT",                    // <-- eklendi
        'show_on_home'     => "INTEGER NOT NULL DEFAULT 0",
        'is_active'        => "INTEGER NOT NULL DEFAULT 1",
        'meta_description' => "TEXT",
        'meta_keywords'    => "TEXT",
        'created_at'       => "DATETIME",
        'updated_at'       => "DATETIME",
    ];
    foreach ($cols as $name => $type) {
        if (!$this->columnExists('news', $name)) {
            $this->db->exec("ALTER TABLE news ADD COLUMN $name $type");
        }
    }
}


    private function createIndexes(): void
    {
        if ($this->columnExists('news','is_active')) {
            $this->db->exec("CREATE INDEX IF NOT EXISTS idx_news_active ON news(is_active)");
        }
        if ($this->columnExists('news','show_on_home')) {
            $this->db->exec("CREATE INDEX IF NOT EXISTS idx_news_home ON news(show_on_home)");
        }
    }

    // ... (paginate/find/create/update/delete/toggle metodların aynı kalabilir)


    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE title LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM news $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM news $where
          ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM news WHERE id=?");
        $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO news
          (sort_order,title,slug,cover_path,content,show_on_home,is_active,meta_description,meta_keywords,created_at,updated_at)
          VALUES(:sort,:title,:slug,:cover,:content,:home,:act,:md,:mk,datetime('now'),datetime('now'))");
        $st->execute([
          ':sort'=>(int)($d['sort_order']??1),
          ':title'=>$d['title'],
          ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null,
          ':content'=>$d['content']??null,
          ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0,
          ':md'=>$d['meta_description']??null,
          ':mk'=>$d['meta_keywords']??null,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE news SET
          sort_order=:sort,title=:title,slug=:slug,
          cover_path=COALESCE(:cover,cover_path),
          content=:content,show_on_home=:home,is_active=:act,
          meta_description=:md,meta_keywords=:mk,
          updated_at=datetime('now')
          WHERE id=:id");
        $st->execute([
          ':id'=>$id,
          ':sort'=>(int)($d['sort_order']??1),
          ':title'=>$d['title'],
          ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null,
          ':content'=>$d['content']??null,
          ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0,
          ':md'=>$d['meta_description']??null,
          ':mk'=>$d['meta_keywords']??null,
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM news WHERE id=?");
        $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE news SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

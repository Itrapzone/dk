<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Course
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            title TEXT NOT NULL,
            slug TEXT,
            cover_path TEXT,
            show_on_home INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            content TEXT,
            meta_description TEXT,
            meta_keywords TEXT,
            created_at DATETIME, updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_courses_active ON courses(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE title LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM courses $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM courses $where
          ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM courses WHERE id=?");
        $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO courses
          (sort_order,title,slug,cover_path,show_on_home,is_active,content,meta_description,meta_keywords,created_at,updated_at)
          VALUES(:sort,:title,:slug,:cover,:home,:act,:content,:md,:mk,datetime('now'),datetime('now'))");
        $st->execute([
          ':sort'=>(int)($d['sort_order']??1), ':title'=>$d['title'], ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null, ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0, ':content'=>$d['content']??null,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE courses SET
          sort_order=:sort,title=:title,slug=:slug,
          cover_path=COALESCE(:cover,cover_path),
          show_on_home=:home,is_active=:act,content=:content,
          meta_description=:md,meta_keywords=:mk,updated_at=datetime('now')
          WHERE id=:id");
        $st->execute([
          ':id'=>$id, ':sort'=>(int)($d['sort_order']??1), ':title'=>$d['title'], ':slug'=>$d['slug'],
          ':cover'=>$d['cover_path']??null, ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0, ':content'=>$d['content']??null,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM courses WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE courses SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

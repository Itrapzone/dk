<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class AdminTranslation
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS admin_translations (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              tkey TEXT NOT NULL,            -- anahtar (örn: txt101)
              description TEXT,              -- açıklama / nerede kullanıldığı
              lang_code TEXT NOT NULL,       -- tr, en, ...
              value TEXT,                    -- dil karşılığı
              created_at DATETIME,
              updated_at DATETIME,
              UNIQUE(tkey, lang_code)
            );
        ");
    }

    /** Listeleme: sadece anahtar bazında tekil satırlar döner (açıklama alanından). */
    public function paginateKeys(int $page=1, int $per=20, string $q=''): array
    {
        $off = ($page-1)*$per;
        $where = $q!=='' ? "WHERE tkey LIKE :q OR description LIKE :q" : "";
        $stmt = $this->db->prepare("SELECT COUNT(DISTINCT tkey) FROM admin_translations $where");
        if ($q!=='') $stmt->bindValue(':q','%'.$q.'%');
        $stmt->execute();
        $total = (int)$stmt->fetchColumn();

        $sql = "SELECT tkey, MAX(description) AS description
                FROM admin_translations
                $where
                GROUP BY tkey
                ORDER BY tkey ASC
                LIMIT :per OFFSET :off";
        $st = $this->db->prepare($sql);
        if ($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per, PDO::PARAM_INT);
        $st->bindValue(':off',$off, PDO::PARAM_INT);
        $st->execute();
        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC), 'total'=>$total];
    }

    public function getOne(string $key, string $lang): array
    {
        $st = $this->db->prepare("SELECT * FROM admin_translations WHERE tkey=? AND lang_code=?");
        $st->execute([$key,$lang]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: ['tkey'=>$key,'lang_code'=>$lang,'description'=>'','value'=>''];
    }

    public function upsert(string $key, string $lang, string $description, string $value): void
    {
        $st = $this->db->prepare("
            INSERT INTO admin_translations (tkey, lang_code, description, value, created_at, updated_at)
            VALUES (:k,:l,:d,:v, datetime('now'), datetime('now'))
            ON CONFLICT(tkey,lang_code) DO UPDATE SET
              description=excluded.description,
              value=excluded.value,
              updated_at=datetime('now')
        ");
        $st->execute([':k'=>$key,':l'=>$lang,':d'=>$description,':v'=>$value]);
    }

    /** Basit seed (isteğe bağlı): yoksa anahtar oluştur. */
    public function ensureKey(string $key, string $desc=''): void
    {
        $st = $this->db->prepare("SELECT 1 FROM admin_translations WHERE tkey=? LIMIT 1");
        $st->execute([$key]);
        if (!$st->fetchColumn()) {
            // default Türkçe kaydı
            $ins = $this->db->prepare("INSERT INTO admin_translations(tkey,description,lang_code,value,created_at,updated_at)
                    VALUES(?, ?, 'tr', '', datetime('now'), datetime('now'))");
            $ins->execute([$key,$desc]);
        }
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Faq
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS faqs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            question TEXT NOT NULL,
            answer TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME, updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_faqs_active ON faqs(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE question LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM faqs $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM faqs $where
            ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM faqs WHERE id=?"); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO faqs
            (sort_order,question,answer,is_active,created_at,updated_at)
            VALUES(:sort,:q,:a,:act,datetime('now'),datetime('now'))");
        $st->execute([
            ':sort'=>(int)($d['sort_order']??1),
            ':q'=>$d['question'],
            ':a'=>$d['answer']??null,
            ':act'=>!empty($d['is_active'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE faqs SET
            sort_order=:sort, question=:q, answer=:a, is_active=:act,
            updated_at=datetime('now') WHERE id=:id");
        $st->execute([
            ':id'=>$id,
            ':sort'=>(int)($d['sort_order']??1),
            ':q'=>$d['question'],
            ':a'=>$d['answer']??null,
            ':act'=>!empty($d['is_active'])?1:0
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM faqs WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE faqs SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class GalleryAlbum
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS gallery_albums (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            title TEXT NOT NULL,
            cover_path TEXT,
            content TEXT,
            show_on_home INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            meta_description TEXT,
            meta_keywords TEXT,
            created_at DATETIME, updated_at DATETIME
          );
        ");
        // eski tabloları yükselt
        $cols = $this->db->query("PRAGMA table_info(gallery_albums)")
                         ->fetchAll(PDO::FETCH_COLUMN,1);
        foreach ([
          'sort_order'=>"INTEGER NOT NULL DEFAULT 1",
          'title'=>"TEXT",'cover_path'=>"TEXT",'content'=>"TEXT",
          'show_on_home'=>"INTEGER NOT NULL DEFAULT 0",
          'is_active'=>"INTEGER NOT NULL DEFAULT 1",
          'meta_description'=>"TEXT",'meta_keywords'=>"TEXT",
          'created_at'=>"DATETIME",'updated_at'=>"DATETIME",
        ] as $c=>$t) { if(!in_array($c,$cols,true)) $this->db->exec("ALTER TABLE gallery_albums ADD COLUMN $c $t"); }
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_gal_alb_active ON gallery_albums(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per; $where=$q!==''?"WHERE title LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM gallery_albums $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM gallery_albums $where
          ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM gallery_albums WHERE id=?");
        $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO gallery_albums
          (sort_order,title,cover_path,content,show_on_home,is_active,meta_description,meta_keywords,created_at,updated_at)
          VALUES(:sort,:title,:cover,:content,:home,:act,:md,:mk,datetime('now'),datetime('now'))");
        $st->execute([
          ':sort'=>$d['sort_order']??1, ':title'=>$d['title'],
          ':cover'=>$d['cover_path']??null, ':content'=>$d['content']??null,
          ':home'=>!empty($d['show_on_home'])?1:0, ':act'=>!empty($d['is_active'])?1:0,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE gallery_albums SET
          sort_order=:sort, title=:title, cover_path=COALESCE(:cover,cover_path),
          content=:content, show_on_home=:home, is_active=:act,
          meta_description=:md, meta_keywords=:mk, updated_at=datetime('now')
          WHERE id=:id");
        $st->execute([
          ':id'=>$id, ':sort'=>$d['sort_order']??1, ':title'=>$d['title'],
          ':cover'=>$d['cover_path']??null, ':content'=>$d['content']??null,
          ':home'=>!empty($d['show_on_home'])?1:0, ':act'=>!empty($d['is_active'])?1:0,
          ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null
        ]);
    }

    public function delete(int $id): void {
        $this->db->prepare("DELETE FROM gallery_albums WHERE id=?")->execute([$id]);
        // Foto’ları da temizleyelim
        $this->db->prepare("DELETE FROM gallery_photos WHERE album_id=?")->execute([$id]);
    }

    public function setCover(int $id,string $path): void {
        $st=$this->db->prepare("UPDATE gallery_albums SET cover_path=:p, updated_at=datetime('now') WHERE id=:id");
        $st->execute([':id'=>$id, ':p'=>$path]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE gallery_albums SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

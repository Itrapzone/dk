<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class SmsClient
{
    public function __construct(private PDO $db) {}

    public function send(string $to, string $message): bool
    {
        $s = (new Settings($this->db))->getAll();
        if (empty($s['sms_active'])) return false;

        $url = $s['sms_post_url']; $user = $s['sms_user']; $sec = $s['sms_secret']; $title = $s['sms_title'];
        if (!$url || !$user || !$sec || !$title) return false;

        $payload = [
            'username' => $user,
            'password' => $sec,
            'title'    => $title,
            'to'       => $to,
            'text'     => $message,
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 15,
        ]);
        $res = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $err === '' && $code >= 200 && $code < 300;
    }
}

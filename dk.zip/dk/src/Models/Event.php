<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Event
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT,
            start_date TEXT,      -- YYYY-MM-DD
            end_date TEXT,        -- YYYY-MM-DD
            location TEXT,
            map_embed TEXT,
            cover_path TEXT,
            content TEXT,
            meta_description TEXT,
            meta_keywords TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at DATETIME,
            updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_events_active ON events(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off = ($page-1)*$per;
        $where = $q!=='' ? "WHERE title LIKE :q OR location LIKE :q" : "";
        $count = $this->db->prepare("SELECT COUNT(*) FROM events $where");
        if($q!=='') $count->bindValue(':q','%'.$q.'%');
        $count->execute(); $total=(int)$count->fetchColumn();

        $sql = "SELECT * FROM events $where ORDER BY COALESCE(start_date,'9999-12-31') DESC, id DESC LIMIT :per OFFSET :off";
        $st  = $this->db->prepare($sql);
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();
        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM events WHERE id=?"); $st->execute([$id]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("
          INSERT INTO events(title,slug,start_date,end_date,location,map_embed,cover_path,content,
                             meta_description,meta_keywords,is_active,created_at,updated_at)
          VALUES(:title,:slug,:sd,:ed,:loc,:map,:cover,:content,:md,:mk,:act,datetime('now'),datetime('now'))
        ");
        $st->execute([
          ':title'=>$d['title'], ':slug'=>$d['slug'], ':sd'=>$d['start_date']??null, ':ed'=>$d['end_date']??null,
          ':loc'=>$d['location']??null, ':map'=>$d['map_embed']??null, ':cover'=>$d['cover_path']??null,
          ':content'=>$d['content']??null, ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("
          UPDATE events SET title=:title, slug=:slug, start_date=:sd, end_date=:ed, location=:loc,
            map_embed=:map, cover_path=COALESCE(:cover, cover_path), content=:content,
            meta_description=:md, meta_keywords=:mk, is_active=:act, updated_at=datetime('now')
          WHERE id=:id
        ");
        $st->execute([
          ':id'=>$id, ':title'=>$d['title'], ':slug'=>$d['slug'], ':sd'=>$d['start_date']??null, ':ed'=>$d['end_date']??null,
          ':loc'=>$d['location']??null, ':map'=>$d['map_embed']??null, ':cover'=>$d['cover_path']??null,
          ':content'=>$d['content']??null, ':md'=>$d['meta_description']??null, ':mk'=>$d['meta_keywords']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM events WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE events SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Slider
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS sliders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,   -- Slayt sıra nosu
            title TEXT,                               -- Slayt başlığı
            url TEXT,                                 -- Slayt URL
            new_tab INTEGER NOT NULL DEFAULT 0,       -- yeni sekme?
            image_path TEXT,                          -- görsel
            description TEXT,                         -- açıklama
            is_active INTEGER NOT NULL DEFAULT 1,     -- durum
            created_at DATETIME, updated_at DATETIME
          );
        ");
        // Eski tabloysa eksik kolonları ekle
        foreach ([
          'sort_order'=>"INTEGER NOT NULL DEFAULT 1",
          'title'=>"TEXT",'url'=>"TEXT",'new_tab'=>"INTEGER NOT NULL DEFAULT 0",
          'image_path'=>"TEXT",'description'=>"TEXT",'is_active'=>"INTEGER NOT NULL DEFAULT 1",
          'created_at'=>"DATETIME",'updated_at'=>"DATETIME"
        ] as $c=>$t){
          $cols=$this->db->query("PRAGMA table_info(sliders)")->fetchAll(PDO::FETCH_COLUMN,1);
          if(!in_array($c,$cols,true)) $this->db->exec("ALTER TABLE sliders ADD COLUMN $c $t");
        }
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_sliders_active ON sliders(is_active)");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_sliders_sort   ON sliders(sort_order)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE title LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM sliders $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM sliders $where
          ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM sliders WHERE id=?");
        $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO sliders
          (sort_order,title,url,new_tab,image_path,description,is_active,created_at,updated_at)
          VALUES(:sort,:title,:url,:tab,:img,:desc,:act,datetime('now'),datetime('now'))");
        $st->execute([
          ':sort'=>$d['sort_order']??1, ':title'=>$d['title']??null,
          ':url'=>$d['url']??null, ':tab'=>!empty($d['new_tab'])?1:0,
          ':img'=>$d['image_path']??null, ':desc'=>$d['description']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE sliders SET
          sort_order=:sort,title=:title,url=:url,new_tab=:tab,
          image_path=COALESCE(:img,image_path),
          description=:desc,is_active=:act,updated_at=datetime('now')
          WHERE id=:id");
        $st->execute([
          ':id'=>$id, ':sort'=>$d['sort_order']??1, ':title'=>$d['title']??null,
          ':url'=>$d['url']??null, ':tab'=>!empty($d['new_tab'])?1:0,
          ':img'=>$d['image_path']??null, ':desc'=>$d['description']??null,
          ':act'=>!empty($d['is_active'])?1:0
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM sliders WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE sliders SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

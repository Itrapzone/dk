<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class AdminUser
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE,
            username TEXT UNIQUE,
            password_hash TEXT,
            avatar_path TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            is_super  INTEGER NOT NULL DEFAULT 0,
            created_at DATETIME, updated_at DATETIME
          );
        ");
        // eski tabloda eksik sütunlar varsa ekle
        $cols=$this->db->query("PRAGMA table_info(users)")->fetchAll(PDO::FETCH_COLUMN,1);
        foreach ([
          'name'=>"TEXT",'email'=>"TEXT",'username'=>"TEXT",'password_hash'=>"TEXT",
          'avatar_path'=>"TEXT",'is_active'=>"INTEGER NOT NULL DEFAULT 1",
          'is_super'=>"INTEGER NOT NULL DEFAULT 0",
          'created_at'=>"DATETIME",'updated_at'=>"DATETIME"
        ] as $c=>$t) if(!in_array($c,$cols,true)) $this->db->exec("ALTER TABLE users ADD COLUMN $c $t");
    }

    public function paginate(int $page=1,int $per=20,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE name LIKE :q OR email LIKE :q OR username LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM users $where");
        if($q!==''){ $cnt->bindValue(':q','%'.$q.'%'); }
        $cnt->execute(); $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM users $where ORDER BY id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $s=$this->db->prepare("SELECT * FROM users WHERE id=?"); $s->execute([$id]);
        return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function findByEmailOrUsername(string $email,string $username,?int $ignoreId=null): ?array {
        $sql="SELECT * FROM users WHERE (email=:e OR username=:u)";
        if($ignoreId){ $sql.=" AND id<>:id"; }
        $s=$this->db->prepare($sql);
        $s->bindValue(':e',$email); $s->bindValue(':u',$username);
        if($ignoreId) $s->bindValue(':id',$ignoreId,PDO::PARAM_INT);
        $s->execute(); return $s->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $s=$this->db->prepare("INSERT INTO users
          (name,email,username,password_hash,avatar_path,is_active,is_super,created_at,updated_at)
          VALUES(:n,:e,:u,:ph,:av,:ac,:sp,datetime('now'),datetime('now'))");
        $s->execute([
          ':n'=>$d['name'], ':e'=>$d['email'], ':u'=>$d['username'],
          ':ph'=>$d['password_hash'], ':av'=>$d['avatar_path']??null,
          ':ac'=>!empty($d['is_active'])?1:0, ':sp'=>!empty($d['is_super'])?1:0
        ]);
        return (int)$this->db->lastInsertId();
    }

   public function update(int $id, array $d): void
{
    $sql = "UPDATE users SET
              name=:n,
              email=:e,
              username=:u,
              avatar_path=COALESCE(:av, avatar_path),
              is_active=:ac,
              is_super=:sp,
              updated_at=datetime('now')";

    // Parametreleri topla
    $params = [
        ':n'  => $d['name'],
        ':e'  => $d['email'],
        ':u'  => $d['username'],
        ':av' => $d['avatar_path'] ?? null,
        ':ac' => !empty($d['is_active']) ? 1 : 0,
        ':sp' => !empty($d['is_super'])  ? 1 : 0,
        ':id' => $id,
    ];

    // Şifre girilmişse hem SQL'e hem parametrelere ekle
    if (!empty($d['password_hash'])) {
        $sql .= ", password_hash=:ph";
        $params[':ph'] = $d['password_hash'];
    }

    $sql .= " WHERE id=:id";

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
}


    public function delete(int $id): void {
        $this->db->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE users SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

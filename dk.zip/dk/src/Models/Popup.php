<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Popup
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS popup_message (
              id INTEGER PRIMARY KEY CHECK (id = 1),
              title TEXT,
              url TEXT,
              target_blank INTEGER DEFAULT 0,
              image_path TEXT,
              is_active INTEGER DEFAULT 0,
              updated_at DATETIME
            );
        ");
        // tek kayıt stratejisi: her zaman id=1
        $this->db->exec("INSERT OR IGNORE INTO popup_message(id,is_active) VALUES(1,0)");
    }

    public function get(): array
    {
        $st = $this->db->query("SELECT * FROM popup_message WHERE id=1 LIMIT 1");
        $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        return array_merge([
            'title' => '',
            'url' => '',
            'target_blank' => 0,
            'image_path' => '',
            'is_active' => 0,
        ], $row);
    }

    public function save(array $data): void
    {
        $st = $this->db->prepare("
            UPDATE popup_message
            SET title=:title, url=:url, target_blank=:tb, image_path=COALESCE(:img, image_path),
                is_active=:active, updated_at=datetime('now')
            WHERE id=1
        ");
        $st->execute([
            ':title' => $data['title'] ?? '',
            ':url'   => $data['url'] ?? '',
            ':tb'    => !empty($data['target_blank']) ? 1 : 0,
            ':img'   => $data['image_path'] ?? null, // null ise mevcut korunur
            ':active'=> !empty($data['is_active']) ? 1 : 0,
        ]);
    }
}

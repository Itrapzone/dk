<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Settings
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
            CREATE TABLE IF NOT EXISTS settings (
              key TEXT PRIMARY KEY,
              value TEXT
            );
        ");
    }

    public function getAll(): array
    {
        $rows = $this->db->query("SELECT key, value FROM settings")->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];

        return array_merge([
            'site_name'         => 'Düşünür Koleji Trabzon',
            'contact_email'     => 'info@okulsite.local',
            'phone'             => '',
            'address'           => '',
            'theme_color_1'     => '#80091C',
            'theme_color_2'     => '#000000',
            'theme_color_3'     => '#f7f7f7',
            'site_url'          => 'https://dusunurkolejitrabzon.com/',
            'homepage_title'    => 'Düşünür Koleji Trabzon',
            'meta_description'  => '',
            'seo_keywords'      => '',           // virgül ile ayrılmış
            'video_youtube_id'  => '',           // tanıtım video ID
            'protected_password'=> '',           // şifreli sayfalar parolası
            'admin_slug'        => 'yonetim',    // /yonetim alias’ı
            'logo_path'         => '',           // /uploads/xxx.png
            'mail_logo_path'    => '',
            'favicon_path'      => '',
            'copyright_text'    => 'Copyright © ' . date('Y') . '.',
            'code_whatsapp'  => '',
            'code_ga'        => '',
            'code_webmaster' => '',
            'code_map_embed' => '',
            'code_livechat'  => '',
            'company_name'    => 'Düşünür Koleji Trabzon',
            'company_phone'   => '',
            'company_fax'     => '',
            'company_email'   => 'info@okulsite.local',
            'company_address' => '',
            'facebook_url'  => '',
            'twitter_url'   => '',
            'instagram_url' => '',
            'linkedin_url'  => '',
            'youtube_url'   => '',
            // Anasayfa modülleri
            'home_slider_info'     => '1',
            'home_egitim_birimleri'=> '1',
            'home_hakkimizda'      => '1',
            'home_kurslar'         => '0',
            'home_istatistik'      => '1',
            'home_kadro'           => '0',
            'home_fotogaleri'      => '1',
            'home_yorumlar'        => '1',
            'home_paketler'        => '0',
            'home_tanitim_video'   => '1',
            'home_referanslar'     => '1',
            'home_haberler'        => '0',

            // Diğer modüller
            'site_loading'         => '1',
            'url_html_suffix'      => '0',
            'force_ssl'            => '1',
            'mod_bursluluk'        => '0',
            'mod_on_kayit'         => '1',
            'mod_is_basvurusu'     => '1',
            'mod_detay_fotogaleri' => '1',
            'mod_detay_videogaleri'=> '1',
            'base_in_subdir'       => '0',
            'site_maintenance'     => '0',
            // Kolon sayılarını (1–6) ve sayfa başı limitleri (pozitif int) tutuyoruz
            'cols_belgeler'         => '3',  'per_belgeler'         => '12',
            'cols_kadro'            => '3',  'per_kadro'            => '24',
            'cols_marka_ortak'      => '3',  'per_marka_ortak'      => '12',
            'cols_fotogaleri'       => '3',  'per_fotogaleri'       => '12',
            'cols_videogaleri'      => '3',  'per_videogaleri'      => '12',
            'cols_haberler'         => '3',  'per_haberler'         => '12',
            'cols_yorumlar'         => '3',  'per_yorumlar'         => '20',
            'cols_dokumanlar'       => '3',  'per_dokumanlar'       => '12',
            'cols_hizmetler'        => '3',  'per_hizmetler'        => '12',
            'cols_egitim_birimleri' => '3',  'per_egitim_birimleri' => '12',
            'cols_kurslar'          => '3',  'per_kurslar'          => '12',
            'cols_subeler'          => '3',  'per_subeler'          => '12',
            'cols_etkinlikler'      => '3',  'per_etkinlikler'      => '12',
            'cols_yemek_menusu'     => '3',  'per_yemek_menusu'     => '12',
            'maintenance_open_date' => '',      // YYYY-MM-DD
            'maintenance_open_time' => '',      // HH:MM (24s)
            'maintenance_title'     => 'SİTEMİZ BAKIMDADIR',
            'maintenance_message'   => 'Şu anda bakımdayız. Kısa süre sonra geri döneceğiz.',
            // Mail
            'smtp_host'   => '',
            'smtp_port'   => '465',
            'smtp_secure' => 'ssl',   // ssl | tls | none
            'smtp_user'   => '',
            'smtp_pass'   => '',      // boş bırakılırsa mevcut korunur
            'smtp_active' => '0',     // 1/0
            'smtp_to'     => '',      // formlar bu adrese düşer
            // SMS
            'sms_post_url' => 'http://sms.bizisms.mobi:8080/api/smspost/v1',
            'sms_user'     => '',
            'sms_secret'   => '',
            'sms_title'    => 'DEMO',   // originator / başlık
            'sms_to'       => '',       // test/varsayılan alıcı
            'sms_active'   => '0',
            'bg_footer'           => '',
            'bg_istatistik'       => '',
            'bg_tanitim_video'    => '',
            'bg_detay_fotogaleri' => '',
            'bg_detay_videogaleri'=> ''


        ], $rows);
    }

    public function save(array $data): void
    {
        $this->db->beginTransaction();
        $st = $this->db->prepare("REPLACE INTO settings(key, value) VALUES(?, ?)");
        foreach ($data as $k => $v) {
            $st->execute([$k, $v]);
        }
        $this->db->commit();
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use PDO;

class Staff
{
    public function __construct(private PDO $db)
    {
        $this->db->exec("
          CREATE TABLE IF NOT EXISTS staff (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sort_order INTEGER NOT NULL DEFAULT 1,
            name TEXT NOT NULL,              -- Başlık / Ad Soyad
            title TEXT,                      -- Görev
            photo_path TEXT,                 -- Profil görseli
            show_detail INTEGER NOT NULL DEFAULT 0,
            show_on_home INTEGER NOT NULL DEFAULT 0,
            is_active INTEGER NOT NULL DEFAULT 1,
            facebook TEXT, twitter TEXT, instagram TEXT, linkedin TEXT, youtube TEXT,
            created_at DATETIME, updated_at DATETIME
          );
        ");
        $this->db->exec("CREATE INDEX IF NOT EXISTS idx_staff_active ON staff(is_active)");
    }

    public function paginate(int $page=1,int $per=10,string $q=''): array {
        $off=($page-1)*$per;
        $where=$q!==''?"WHERE name LIKE :q OR title LIKE :q":"";
        $cnt=$this->db->prepare("SELECT COUNT(*) FROM staff $where");
        if($q!=='') $cnt->bindValue(':q','%'.$q.'%'); $cnt->execute();
        $total=(int)$cnt->fetchColumn();

        $st=$this->db->prepare("SELECT * FROM staff $where
          ORDER BY sort_order ASC, id DESC LIMIT :per OFFSET :off");
        if($q!=='') $st->bindValue(':q','%'.$q.'%');
        $st->bindValue(':per',$per,PDO::PARAM_INT);
        $st->bindValue(':off',$off,PDO::PARAM_INT);
        $st->execute();

        return ['rows'=>$st->fetchAll(PDO::FETCH_ASSOC),'total'=>$total];
    }

    public function find(int $id): ?array {
        $st=$this->db->prepare("SELECT * FROM staff WHERE id=?");
        $st->execute([$id]); return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    public function create(array $d): int {
        $st=$this->db->prepare("INSERT INTO staff
          (sort_order,name,title,photo_path,show_detail,show_on_home,is_active,
           facebook,twitter,instagram,linkedin,youtube,created_at,updated_at)
          VALUES(:sort,:name,:title,:photo,:detail,:home,:act,:fb,:tw,:ig,:li,:yt,datetime('now'),datetime('now'))");
        $st->execute([
          ':sort'=>(int)($d['sort_order']??1), ':name'=>$d['name'], ':title'=>$d['title']??null,
          ':photo'=>$d['photo_path']??null, ':detail'=>!empty($d['show_detail'])?1:0,
          ':home'=>!empty($d['show_on_home'])?1:0, ':act'=>!empty($d['is_active'])?1:0,
          ':fb'=>$d['facebook']??null, ':tw'=>$d['twitter']??null, ':ig'=>$d['instagram']??null,
          ':li'=>$d['linkedin']??null, ':yt'=>$d['youtube']??null
        ]);
        return (int)$this->db->lastInsertId();
    }

    public function update(int $id,array $d): void {
        $st=$this->db->prepare("UPDATE staff SET
          sort_order=:sort,name=:name,title=:title,
          photo_path=COALESCE(:photo,photo_path),
          show_detail=:detail, show_on_home=:home, is_active=:act,
          facebook=:fb, twitter=:tw, instagram=:ig, linkedin=:li, youtube=:yt,
          updated_at=datetime('now') WHERE id=:id");
        $st->execute([
          ':id'=>$id, ':sort'=>(int)($d['sort_order']??1), ':name'=>$d['name'],
          ':title'=>$d['title']??null, ':photo'=>$d['photo_path']??null,
          ':detail'=>!empty($d['show_detail'])?1:0, ':home'=>!empty($d['show_on_home'])?1:0,
          ':act'=>!empty($d['is_active'])?1:0,
          ':fb'=>$d['facebook']??null, ':tw'=>$d['twitter']??null, ':ig'=>$d['instagram']??null,
          ':li'=>$d['linkedin']??null, ':yt'=>$d['youtube']??null
        ]);
    }

    public function delete(int $id): void {
        $st=$this->db->prepare("DELETE FROM staff WHERE id=?"); $st->execute([$id]);
    }

    public function toggle(int $id): void {
        $this->db->exec("UPDATE staff SET is_active=CASE is_active WHEN 1 THEN 0 ELSE 1 END WHERE id={$id}");
    }
}

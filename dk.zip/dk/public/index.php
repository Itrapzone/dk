<?php
declare(strict_types=1);

use App\Core\Router;
use App\Bootstrap;

if (PHP_SAPI === 'cli-server') {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $file = __DIR__ . $path;
    if (is_file($file)) { return false; }
}

require __DIR__ . '/../vendor/autoload.php';
session_start();

$bootstrap = new Bootstrap();
$container = $bootstrap->boot();
$router    = new Router($container);

/** ---- Admin alias (ayarlar üzerinden) ----
 * settings.admin_slug = "yonetim" gibi ise /yonetim -> /admin yönlendir.
 */
try {
    $pdo = $container->get('db');
    $s   = new \App\Models\Settings($pdo);
    $cfg = $s->getAll();
    $alias = '/' . trim($cfg['admin_slug'] ?? 'yonetim', '/');
    if ($alias !== '/admin' && $alias !== '/') {
        $router->get($alias, fn() => header('Location: /admin', true, 303));
    }
} catch (\Throwable $e) {
    // settings tablosu yoksa sessiz geç
}

/** ROUTES **/

// --- AUTH (admin grubunun DIŞINDA, TEK KERE) ---
use App\Controllers\AuthController;
$router->get('/login',  [AuthController::class, 'showLogin']);
$router->post('/login', [AuthController::class, 'login']);
$router->get('/logout', [AuthController::class, 'logout']);

// Anasayfa -> Admin Dashboard
$router->get('/', fn() => header('Location: /admin', true, 303));

// --- ADMIN (korumalı) — TEK GRUP ---
$router->group('/admin', function (Router $r) {

    // /admin kökü -> Dashboard
    $r->get('',  [\App\Controllers\Admin\DashboardController::class, 'index']);
    $r->get('/', [\App\Controllers\Admin\DashboardController::class, 'index']);

    // Haber Yönetimi
    $r->get('/news',                   [\App\Controllers\Admin\NewsController::class, 'index']);
    $r->get('/news/create',            [\App\Controllers\Admin\NewsController::class, 'create']);
    $r->post('/news',                  [\App\Controllers\Admin\NewsController::class, 'store']);
    $r->get('/news/{id:\d+}/edit',     [\App\Controllers\Admin\NewsController::class, 'edit']);
    $r->post('/news/{id:\d+}/update',  [\App\Controllers\Admin\NewsController::class, 'update']);
    $r->post('/news/{id:\d+}/delete',  [\App\Controllers\Admin\NewsController::class, 'destroy']);
    $r->post('/news/{id:\d+}/toggle',  [\App\Controllers\Admin\NewsController::class, 'toggle']);

    // Site Yönetimi
    $r->get('/settings/general',      [\App\Controllers\Admin\SettingsController::class, 'general']);
    $r->post('/settings/general',     [\App\Controllers\Admin\SettingsController::class, 'saveGeneral']);

    $r->get('/settings/popup',        [\App\Controllers\Admin\PopupController::class, 'show']);
    $r->post('/settings/popup',       [\App\Controllers\Admin\PopupController::class, 'save']);

    $r->get('/settings/api',          [\App\Controllers\Admin\ApiSettingsController::class, 'show']);
    $r->post('/settings/api',         [\App\Controllers\Admin\ApiSettingsController::class, 'save']);

    $r->get('/settings/contact',      [\App\Controllers\Admin\ContactSettingsController::class, 'show']);
    $r->post('/settings/contact',     [\App\Controllers\Admin\ContactSettingsController::class, 'save']);

    $r->get('/settings/social',       [\App\Controllers\Admin\SocialSettingsController::class, 'show']);
    $r->post('/settings/social',      [\App\Controllers\Admin\SocialSettingsController::class, 'save']);

    $r->get('/settings/modules',      [\App\Controllers\Admin\ModuleSettingsController::class, 'show']);
    $r->post('/settings/modules',     [\App\Controllers\Admin\ModuleSettingsController::class, 'save']);

    $r->get('/settings/limits',       [\App\Controllers\Admin\LimitSettingsController::class, 'show']);
    $r->post('/settings/limits',      [\App\Controllers\Admin\LimitSettingsController::class, 'save']);

    $r->get('/settings/maintenance',  [\App\Controllers\Admin\MaintenanceController::class, 'show']);
    $r->post('/settings/maintenance', [\App\Controllers\Admin\MaintenanceController::class, 'save']);

    $r->get('/settings/mail',         [\App\Controllers\Admin\MailSettingsController::class, 'show']);
    $r->post('/settings/mail',        [\App\Controllers\Admin\MailSettingsController::class, 'save']);

    $r->get('/settings/sms',          [\App\Controllers\Admin\SmsSettingsController::class, 'show']);
    $r->post('/settings/sms',         [\App\Controllers\Admin\SmsSettingsController::class, 'save']);

    $r->get('/settings/backgrounds',  [\App\Controllers\Admin\BackgroundController::class, 'show']);
    $r->post('/settings/backgrounds', [\App\Controllers\Admin\BackgroundController::class, 'save']);

    // Dil Yönetimi
    $r->get('/languages',                   [\App\Controllers\Admin\LanguageController::class, 'index']);
    $r->get('/languages/create',            [\App\Controllers\Admin\LanguageController::class, 'create']);
    $r->post('/languages',                  [\App\Controllers\Admin\LanguageController::class, 'store']);
    $r->get('/languages/{id:\d+}/edit',     [\App\Controllers\Admin\LanguageController::class, 'edit']);
    $r->post('/languages/{id:\d+}/update',  [\App\Controllers\Admin\LanguageController::class, 'update']);
    $r->post('/languages/{id:\d+}/delete',  [\App\Controllers\Admin\LanguageController::class, 'destroy']);
    $r->post('/languages/{id:\d+}/toggle',  [\App\Controllers\Admin\LanguageController::class, 'toggle']);
    $r->post('/languages/{id:\d+}/default', [\App\Controllers\Admin\LanguageController::class, 'makeDefault']);

    // Admin Panel Dil Ayarı
    $r->get('/admin-lang',                          [\App\Controllers\Admin\AdminLangController::class, 'index']);
    $r->get('/admin-lang/{key:[A-Za-z0-9_\-\.]+}/edit',   [\App\Controllers\Admin\AdminLangController::class, 'edit']);
    $r->post('/admin-lang/{key:[A-Za-z0-9_\-\.]+}/update',[\App\Controllers\Admin\AdminLangController::class, 'update']);

    // Etkinlik Yönetimi
    $r->get('/events',                   [\App\Controllers\Admin\EventController::class, 'index']);
    $r->get('/events/create',            [\App\Controllers\Admin\EventController::class, 'create']);
    $r->post('/events',                  [\App\Controllers\Admin\EventController::class, 'store']);
    $r->get('/events/{id:\d+}/edit',     [\App\Controllers\Admin\EventController::class, 'edit']);
    $r->post('/events/{id:\d+}/update',  [\App\Controllers\Admin\EventController::class, 'update']);
    $r->post('/events/{id:\d+}/delete',  [\App\Controllers\Admin\EventController::class, 'destroy']);
    $r->post('/events/{id:\d+}/toggle',  [\App\Controllers\Admin\EventController::class, 'toggle']);

    // Sayfa Yönetimi
    $r->get('/pages',                   [\App\Controllers\Admin\PageController::class, 'index']);
    $r->get('/pages/create',            [\App\Controllers\Admin\PageController::class, 'create']);
    $r->post('/pages',                  [\App\Controllers\Admin\PageController::class, 'store']);
    $r->get('/pages/{id:\d+}/edit',     [\App\Controllers\Admin\PageController::class, 'edit']);
    $r->post('/pages/{id:\d+}/update',  [\App\Controllers\Admin\PageController::class, 'update']);
    $r->post('/pages/{id:\d+}/delete',  [\App\Controllers\Admin\PageController::class, 'destroy']);
    $r->post('/pages/{id:\d+}/toggle',  [\App\Controllers\Admin\PageController::class, 'toggle']);

    // Hizmet Yönetimi
    $r->get('/services',                   [\App\Controllers\Admin\ServiceController::class, 'index']);
    $r->get('/services/create',            [\App\Controllers\Admin\ServiceController::class, 'create']);
    $r->post('/services',                  [\App\Controllers\Admin\ServiceController::class, 'store']);
    $r->get('/services/{id:\d+}/edit',     [\App\Controllers\Admin\ServiceController::class, 'edit']);
    $r->post('/services/{id:\d+}/update',  [\App\Controllers\Admin\ServiceController::class, 'update']);
    $r->post('/services/{id:\d+}/delete',  [\App\Controllers\Admin\ServiceController::class, 'destroy']);
    $r->post('/services/{id:\d+}/toggle',  [\App\Controllers\Admin\ServiceController::class, 'toggle']);

    // Eğitim Birimleri
    $r->get('/departments',                   [\App\Controllers\Admin\EduUnitController::class, 'index']);
    $r->get('/departments/create',            [\App\Controllers\Admin\EduUnitController::class, 'create']);
    $r->post('/departments',                  [\App\Controllers\Admin\EduUnitController::class, 'store']);
    $r->get('/departments/{id:\d+}/edit',     [\App\Controllers\Admin\EduUnitController::class, 'edit']);
    $r->post('/departments/{id:\d+}/update',  [\App\Controllers\Admin\EduUnitController::class, 'update']);
    $r->post('/departments/{id:\d+}/delete',  [\App\Controllers\Admin\EduUnitController::class, 'destroy']);
    $r->post('/departments/{id:\d+}/toggle',  [\App\Controllers\Admin\EduUnitController::class, 'toggle']);

    // Kurs Yönetimi
    $r->get('/courses',                   [\App\Controllers\Admin\CourseController::class, 'index']);
    $r->get('/courses/create',            [\App\Controllers\Admin\CourseController::class, 'create']);
    $r->post('/courses',                  [\App\Controllers\Admin\CourseController::class, 'store']);
    $r->get('/courses/{id:\d+}/edit',     [\App\Controllers\Admin\CourseController::class, 'edit']);
    $r->post('/courses/{id:\d+}/update',  [\App\Controllers\Admin\CourseController::class, 'update']);
    $r->post('/courses/{id:\d+}/delete',  [\App\Controllers\Admin\CourseController::class, 'destroy']);
    $r->post('/courses/{id:\d+}/toggle',  [\App\Controllers\Admin\CourseController::class, 'toggle']);

    // S.S.S
    $r->get('/faqs',                   [\App\Controllers\Admin\FaqController::class, 'index']);
    $r->get('/faqs/create',            [\App\Controllers\Admin\FaqController::class, 'create']);
    $r->post('/faqs',                  [\App\Controllers\Admin\FaqController::class, 'store']);
    $r->get('/faqs/{id:\d+}/edit',     [\App\Controllers\Admin\FaqController::class, 'edit']);
    $r->post('/faqs/{id:\d+}/update',  [\App\Controllers\Admin\FaqController::class, 'update']);
    $r->post('/faqs/{id:\d+}/delete',  [\App\Controllers\Admin\FaqController::class, 'destroy']);
    $r->post('/faqs/{id:\d+}/toggle',  [\App\Controllers\Admin\FaqController::class, 'toggle']);

    // Marka Yönetimi
    $r->get('/brands',                   [\App\Controllers\Admin\BrandController::class, 'index']);
    $r->get('/brands/create',            [\App\Controllers\Admin\BrandController::class, 'create']);
    $r->post('/brands',                  [\App\Controllers\Admin\BrandController::class, 'store']);
    $r->get('/brands/{id:\d+}/edit',     [\App\Controllers\Admin\BrandController::class, 'edit']);
    $r->post('/brands/{id:\d+}/update',  [\App\Controllers\Admin\BrandController::class, 'update']);
    $r->post('/brands/{id:\d+}/delete',  [\App\Controllers\Admin\BrandController::class, 'destroy']);
    $r->post('/brands/{id:\d+}/toggle',  [\App\Controllers\Admin\BrandController::class, 'toggle']);

    // Yemek Menüsü
    $r->get('/meal-menus',                   [\App\Controllers\Admin\MealMenuController::class, 'index']);
    $r->get('/meal-menus/create',            [\App\Controllers\Admin\MealMenuController::class, 'create']);
    $r->post('/meal-menus',                  [\App\Controllers\Admin\MealMenuController::class, 'store']);
    $r->get('/meal-menus/{id:\d+}/edit',     [\App\Controllers\Admin\MealMenuController::class, 'edit']);
    $r->post('/meal-menus/{id:\d+}/update',  [\App\Controllers\Admin\MealMenuController::class, 'update']);
    $r->post('/meal-menus/{id:\d+}/delete',  [\App\Controllers\Admin\MealMenuController::class, 'destroy']);
    $r->post('/meal-menus/{id:\d+}/toggle',  [\App\Controllers\Admin\MealMenuController::class, 'toggle']);

    // Belge Yönetimi
    $r->get('/documents',                   [\App\Controllers\Admin\DocumentController::class, 'index']);
    $r->get('/documents/create',            [\App\Controllers\Admin\DocumentController::class, 'create']);
    $r->post('/documents',                  [\App\Controllers\Admin\DocumentController::class, 'store']);
    $r->get('/documents/{id:\d+}/edit',     [\App\Controllers\Admin\DocumentController::class, 'edit']);
    $r->post('/documents/{id:\d+}/update',  [\App\Controllers\Admin\DocumentController::class, 'update']);
    $r->post('/documents/{id:\d+}/delete',  [\App\Controllers\Admin\DocumentController::class, 'destroy']);
    $r->post('/documents/{id:\d+}/toggle',  [\App\Controllers\Admin\DocumentController::class, 'toggle']);

    // Eğitim Kadromuz
    $r->get('/staff',                   [\App\Controllers\Admin\StaffController::class, 'index']);
    $r->get('/staff/create',            [\App\Controllers\Admin\StaffController::class, 'create']);
    $r->post('/staff',                  [\App\Controllers\Admin\StaffController::class, 'store']);
    $r->get('/staff/{id:\d+}/edit',     [\App\Controllers\Admin\StaffController::class, 'edit']);
    $r->post('/staff/{id:\d+}/update',  [\App\Controllers\Admin\StaffController::class, 'update']);
    $r->post('/staff/{id:\d+}/delete',  [\App\Controllers\Admin\StaffController::class, 'destroy']);
    $r->post('/staff/{id:\d+}/toggle',  [\App\Controllers\Admin\StaffController::class, 'toggle']);

    // Slider
    $r->get('/sliders',                   [\App\Controllers\Admin\SliderController::class, 'index']);
    $r->get('/sliders/create',            [\App\Controllers\Admin\SliderController::class, 'create']);
    $r->post('/sliders',                  [\App\Controllers\Admin\SliderController::class, 'store']);
    $r->get('/sliders/{id:\d+}/edit',     [\App\Controllers\Admin\SliderController::class, 'edit']);
    $r->post('/sliders/{id:\d+}/update',  [\App\Controllers\Admin\SliderController::class, 'update']);
    $r->post('/sliders/{id:\d+}/delete',  [\App\Controllers\Admin\SliderController::class, 'destroy']);
    $r->post('/sliders/{id:\d+}/toggle',  [\App\Controllers\Admin\SliderController::class, 'toggle']);

    // Foto Galeri
    $r->get('/photo-galleries',                     [\App\Controllers\Admin\GalleryAlbumController::class, 'index']);
    $r->get('/photo-galleries/create',              [\App\Controllers\Admin\GalleryAlbumController::class, 'create']);
    $r->post('/photo-galleries',                    [\App\Controllers\Admin\GalleryAlbumController::class, 'store']);
    $r->get('/photo-galleries/{id:\d+}/edit',       [\App\Controllers\Admin\GalleryAlbumController::class, 'edit']);
    $r->post('/photo-galleries/{id:\d+}/update',    [\App\Controllers\Admin\GalleryAlbumController::class, 'update']);
    $r->post('/photo-galleries/{id:\d+}/delete',    [\App\Controllers\Admin\GalleryAlbumController::class, 'destroy']);
    $r->post('/photo-galleries/{id:\d+}/toggle',    [\App\Controllers\Admin\GalleryAlbumController::class, 'toggle']);
    $r->post('/photo-galleries/{id:\d+}/set-cover', [\App\Controllers\Admin\GalleryAlbumController::class, 'setCover']);
    $r->get('/photo-galleries/{id:\d+}/photos',          [\App\Controllers\Admin\GalleryAlbumController::class, 'photos']);
    $r->post('/photo-galleries/{id:\d+}/photos/upload',  [\App\Controllers\Admin\GalleryAlbumController::class, 'uploadPhotos']);
    $r->post('/photos/{photoId:\d+}/toggle',             [\App\Controllers\Admin\GalleryAlbumController::class, 'togglePhoto']);
    $r->post('/photos/{photoId:\d+}/delete',             [\App\Controllers\Admin\GalleryAlbumController::class, 'deletePhoto']);
    $r->post('/photos/{photoId:\d+}/make-cover',         [\App\Controllers\Admin\GalleryAlbumController::class, 'makePhotoCover']);

    // Yöneticiler
    $r->get('/admins',                  [\App\Controllers\Admin\AdminUserController::class, 'index']);
    $r->get('/admins/create',           [\App\Controllers\Admin\AdminUserController::class, 'create']);
    $r->post('/admins',                 [\App\Controllers\Admin\AdminUserController::class, 'store']);
    $r->get('/admins/{id:\d+}/edit',    [\App\Controllers\Admin\AdminUserController::class, 'edit']);
    $r->post('/admins/{id:\d+}/update', [\App\Controllers\Admin\AdminUserController::class, 'update']);
    $r->post('/admins/{id:\d+}/delete', [\App\Controllers\Admin\AdminUserController::class, 'destroy']);
    $r->post('/admins/{id:\d+}/toggle', [\App\Controllers\Admin\AdminUserController::class, 'toggle']);

}, \App\Middleware\AuthMiddleware::class);

// --- EN SON ---
$router->dispatch();

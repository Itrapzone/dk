# Okul Site (PHP 8.2 - FastRoute + Plates + PDO)

## Kurulum
```bash
composer install
php -S localhost:8000 -t public public/index.php
```
Giriş: **admin@okulsite.local / Admin123!**

> Not: Geliştirme kolaylığı için, veritabanındaki parola düz metin olarak saklanmıştır. `AuthController` hem bcrypt hash'i hem de düz metni kabul eder. Canlıda mutlaka `password_hash` ile hash'e geçin.

## Yapı
- `public/index.php` frontend controller
- `src/Core/Router.php` FastRoute sarmalayıcı
- `src/Bootstrap.php` Dotenv, PDO, Plates, Monolog
- `src/Models/DB.php` PDO bağlantısı
- `views/` Plates şablonları (.phtml)

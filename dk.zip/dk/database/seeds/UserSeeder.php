<?php
declare(strict_types=1);

use Phinx\Seed\AbstractSeed;

class UserSeeder extends AbstractSeed
{
    public function run(): void
    {
        $this->table('users')->insert([
            [
                'name' => 'Sistem Yöneticisi',
                'email' => 'admin@okulsite.local',
                'password' => password_hash('Admin123!', PASSWORD_DEFAULT),
                'role' => 'admin',
            ],
        ])->saveData();
    }
}

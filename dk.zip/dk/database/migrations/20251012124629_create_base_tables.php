<?php
declare(strict_types=1);

use Phinx\Migration\AbstractMigration;

final class CreateBaseTables extends AbstractMigration
{
    public function change(): void
    {
        $this->table('users')
            ->addColumn('name', 'string')
            ->addColumn('email', 'string', ['limit' => 190])
            ->addColumn('password', 'string', ['limit' => 255])
            ->addColumn('role', 'string', ['default' => 'admin'])
            ->addIndex(['email'], ['unique' => true])
            ->create();

        $this->table('news')
            ->addColumn('title', 'string')
            ->addColumn('slug', 'string', ['limit' => 190])
            ->addColumn('excerpt', 'text', ['null' => true])
            ->addColumn('body', 'text', ['null' => true])
            ->addColumn('publish_at', 'datetime', ['null' => true])
            ->addColumn('is_published', 'boolean', ['default' => false])
            ->addColumn('created_at', 'datetime', ['null' => true])
            ->addColumn('updated_at', 'datetime', ['null' => true])
            ->addIndex(['slug'], ['unique' => true])
            ->create();
    }
}

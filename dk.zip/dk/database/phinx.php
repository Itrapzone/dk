<?php
return [
  'paths' => [
    'migrations' => __DIR__ . '/migrations',
    'seeds'      => __DIR__ . '/seeds',
  ],
  'environments' => [
    'default_migration_table' => 'migrations',
    'default_environment' => 'local',
    'local' => [
      'adapter' => getenv('DB_DRIVER') === 'mysql' ? 'mysql' : 'sqlite',
      'host' => getenv('DB_HOST') ?: '127.0.0.1',
      'name' => getenv('DB_DATABASE') ?: __DIR__ . '/../okulsite.sqlite',
      'user' => getenv('DB_USERNAME') ?: 'root',
      'pass' => getenv('DB_PASSWORD') ?: '',
      'port' => getenv('DB_PORT') ?: '3306',
      'charset' => 'utf8mb4',
    ],
  ],
  'version_order' => 'creation'
];
